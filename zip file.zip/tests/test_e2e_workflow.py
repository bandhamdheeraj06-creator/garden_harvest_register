"""End-to-end integration and user journey validation test."""

import unittest
import tempfile
import shutil
from pathlib import Path
from garden_harvest.models import HarvestRecord, CropCategory, QualityGrade
from garden_harvest.persistence import StorageManager
from garden_harvest.business_logic import BusinessLogicEngine
from garden_harvest.search import QueryEngine
from garden_harvest.analytics import AnalyticsEngine
from garden_harvest.exporter import ReportExporter


class TestE2EWorkflow(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.storage = StorageManager(data_dir=self.temp_dir)

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_complete_user_lifecycle(self):
        # Step 1: Initialize clean storage
        records, warnings = self.storage.load_records()
        self.assertEqual(len(records), 0)

        # Step 2: Record multiple harvests across consecutive weeks
        h1 = HarvestRecord("Snap Peas", CropCategory.LEGUME.value, 5.0, "kg", "2026-07-06", "Bed-1", QualityGrade.GRADE_A.value, 20.0)
        h2 = HarvestRecord("Strawberries", CropCategory.BERRY.value, 3.0, "kg", "2026-07-08", "Orchard-Plot", QualityGrade.GRADE_A.value, 18.0)
        h3 = HarvestRecord("Roma Tomatoes", CropCategory.FRUIT.value, 16.0, "kg", "2026-07-14", "Bed-1", QualityGrade.GRADE_A.value, 48.0)
        h4 = HarvestRecord("Zucchini", CropCategory.VEGETABLE.value, 12.0, "kg", "2026-07-16", "Bed-2", QualityGrade.GRADE_A.value, 24.0)

        self.storage.save_records([h1, h2, h3, h4])

        # Step 3: Verify Persistence survives restart
        reloaded_storage = StorageManager(data_dir=self.temp_dir)
        reloaded_records, _ = reloaded_storage.load_records()
        self.assertEqual(len(reloaded_records), 4)

        # Step 4: Business Logic - Weekly Totals
        weekly = BusinessLogicEngine.calculate_weekly_totals(reloaded_records)
        self.assertEqual(len(weekly), 2)
        # Week 28 total: 5.0 + 3.0 = 8.0 kg
        self.assertEqual(weekly[0]["total_weight_kg"], 8.0)
        # Week 29 total: 16.0 + 12.0 = 28.0 kg -> growth surge
        self.assertEqual(weekly[1]["total_weight_kg"], 28.0)
        self.assertIn("📈", weekly[1]["trend_symbol"])
        self.assertEqual(weekly[1]["pct_change"], 250.0)

        # Step 5: Query & Search
        searched = QueryEngine.filter_records(reloaded_records, category="Fruit")
        self.assertEqual(len(searched), 1)
        self.assertEqual(searched[0].crop_name, "Roma Tomatoes")

        # Step 6: Executive Analytics
        summary = AnalyticsEngine.generate_executive_summary(reloaded_records, weekly_target_kg=15.0)
        self.assertEqual(summary["total_records"], 4)
        self.assertEqual(summary["total_weight_kg"], 36.0)
        self.assertEqual(summary["total_estimated_value"], 110.0)

        # Step 7: Export multi-format summaries
        export_dir = Path(self.temp_dir) / "exports"
        md_path = export_dir / "report.md"
        txt_path = export_dir / "audit.txt"
        ReportExporter.export_markdown_report(reloaded_records, str(md_path))
        ReportExporter.export_audit_log(reloaded_records, str(txt_path))

        self.assertTrue(md_path.exists())
        self.assertTrue(txt_path.exists())
        self.assertGreater(md_path.stat().st_size, 200)
        self.assertGreater(txt_path.stat().st_size, 200)


if __name__ == "__main__":
    unittest.main()
