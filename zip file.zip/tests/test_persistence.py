"""Unit tests for local file persistence, recovery, and schema handling."""

import os
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from garden_harvest.models import HarvestRecord
from garden_harvest.persistence import StorageManager


class TestPersistence(unittest.TestCase):

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.storage = StorageManager(data_dir=self.test_dir)

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_missing_file_initialization(self):
        records, warnings = self.storage.load_records()
        self.assertEqual(len(records), 0)
        self.assertTrue(len(warnings) > 0)
        self.assertTrue(self.storage.json_path.exists())

    def test_save_and_reload(self):
        rec1 = HarvestRecord("Tomatoes", "Fruit", 12.0, "kg", "2026-08-10", "Bed-1")
        rec2 = HarvestRecord("Kale", "Leafy Green", 15, "pcs", "2026-08-11", "Bed-2")

        self.storage.save_records([rec1, rec2])

        reloaded, warnings = self.storage.load_records()
        self.assertEqual(len(reloaded), 2)
        self.assertEqual(reloaded[0].crop_name, "Tomatoes")
        self.assertEqual(reloaded[1].crop_name, "Kale")
        self.assertTrue(self.storage.csv_path.exists())

    def test_corrupted_file_recovery(self):
        # Deliberately corrupt the JSON file with malformed syntax
        with open(self.storage.json_path, "w", encoding="utf-8") as f:
            f.write("{corrupted_malformed_json: true, unterminated...")

        records, warnings = self.storage.load_records()
        self.assertEqual(len(records), 0)
        # Verify a warning was emitted and clean template re-established
        self.assertTrue(any("CORRUPTION DETECTED" in w for w in warnings))

        # Check backup file was created
        bak_files = list(Path(self.test_dir).glob("*.bak"))
        self.assertTrue(len(bak_files) >= 1)


if __name__ == "__main__":
    unittest.main()
