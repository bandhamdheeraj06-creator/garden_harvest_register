"""Unit tests for business logic, weekly totals calculation, and aggregations."""

import unittest
from garden_harvest.models import HarvestRecord, QualityGrade
from garden_harvest.business_logic import BusinessLogicEngine


class TestBusinessLogic(unittest.TestCase):

    def setUp(self):
        # 3 records in Week 33 (2026-08-10 to 2026-08-16)
        self.r1 = HarvestRecord("Tomatoes", "Fruit", 10.0, "kg", "2026-08-11", "Bed-1", QualityGrade.GRADE_A.value, 30.0)
        self.r2 = HarvestRecord("Kale", "Leafy Green", 5, "bunches", "2026-08-12", "Bed-2", QualityGrade.GRADE_A.value, 15.0)
        self.r3 = HarvestRecord("Peppers", "Vegetable", 4.0, "kg", "2026-08-14", "Bed-1", QualityGrade.GRADE_B.value, 12.0)

        # 2 records in Week 34 (2026-08-17 to 2026-08-23) - higher yield
        self.r4 = HarvestRecord("Tomatoes", "Fruit", 20.0, "kg", "2026-08-18", "Bed-1", QualityGrade.GRADE_A.value, 60.0)
        self.r5 = HarvestRecord("Basil", "Herb", 1000, "g", "2026-08-20", "Bed-3", QualityGrade.GRADE_A.value, 20.0)

        self.records = [self.r1, self.r2, self.r3, self.r4, self.r5]

    def test_weekly_totals_grouping_and_sums(self):
        weekly = BusinessLogicEngine.calculate_weekly_totals(self.records)
        self.assertEqual(len(weekly), 2)

        w1 = weekly[0]
        self.assertEqual(w1["week_key"], "2026-W33")
        # Total weight: 10.0 (tomatoes) + 4.0 (peppers) = 14.0 kg. (Kale is discrete bunches)
        self.assertEqual(w1["total_weight_kg"], 14.0)
        self.assertEqual(w1["total_items_count"], 5)
        self.assertEqual(w1["total_value"], 57.0)

        w2 = weekly[1]
        self.assertEqual(w2["week_key"], "2026-W34")
        # Total weight: 20.0 (tomatoes) + 1.0 (basil 1000g) = 21.0 kg
        self.assertEqual(w2["total_weight_kg"], 21.0)
        self.assertEqual(w2["total_value"], 80.0)

        # Trend check: from 14.0 to 21.0 is +50.0%
        self.assertIn("📈", w2["trend_symbol"])
        self.assertEqual(w2["pct_change"], 50.0)

    def test_category_breakdown(self):
        cat_data = BusinessLogicEngine.calculate_category_breakdown(self.records)
        self.assertIn("Fruit", cat_data)
        self.assertEqual(cat_data["Fruit"]["total_kg"], 30.0)
        self.assertIn("Leafy Green", cat_data)
        self.assertEqual(cat_data["Leafy Green"]["total_count"], 5)

    def test_bed_yields(self):
        bed_data = BusinessLogicEngine.calculate_bed_yields(self.records)
        self.assertIn("Bed-1", bed_data)
        self.assertEqual(bed_data["Bed-1"]["total_kg"], 34.0)
        self.assertEqual(bed_data["Bed-1"]["entries"], 3)


if __name__ == "__main__":
    unittest.main()
