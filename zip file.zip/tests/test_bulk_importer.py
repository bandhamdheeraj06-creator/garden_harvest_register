"""Unit tests for bulk legacy CSV ingestion and error logging."""

import os
import unittest
from pathlib import Path
from garden_harvest.bulk_importer import BulkDatasetImporter


class TestBulkImporter(unittest.TestCase):

    def test_legacy_sample_import_with_error_logging(self):
        sample_path = Path(__file__).resolve().parent.parent / "data" / "legacy_import_sample.csv"
        self.assertTrue(sample_path.exists(), f"Sample file {sample_path} should exist")

        res = BulkDatasetImporter.import_csv(str(sample_path))
        self.assertGreater(res.total_rows, 0)
        self.assertGreater(res.success_count, 0)
        # Deliberate erroneous rows in test dataset must be captured in row_errors
        self.assertGreater(res.error_count, 0)
        self.assertEqual(len(res.imported_records), res.success_count)
        self.assertEqual(len(res.row_errors), res.error_count)

        # Check that error fields are identified
        error_fields = [e["field"] for e in res.row_errors]
        self.assertTrue(any("Quantity" in f or "multiple" in f for f in error_fields))


if __name__ == "__main__":
    unittest.main()
