"""Unit tests for models and data normalization."""

import unittest
from datetime import date
from garden_harvest.models import HarvestRecord, CropCategory, QualityGrade, HarvestUnit


class TestModels(unittest.TestCase):

    def test_record_creation_and_defaults(self):
        rec = HarvestRecord(
            crop_name="Roma Tomatoes",
            category=CropCategory.FRUIT.value,
            quantity=10.5,
            unit="kg",
            harvest_date="2026-08-15",
            bed_id="Bed-1",
            quality_grade=QualityGrade.GRADE_A.value,
            estimated_value=31.5
        )
        self.assertTrue(rec.id.startswith("HRV-"))
        self.assertEqual(rec.normalized_kg, 10.5)
        self.assertEqual(rec.iso_year, 2026)
        self.assertEqual(rec.iso_week, 33)
        self.assertEqual(rec.week_key, "2026-W33")
        self.assertTrue(rec.is_weight_unit)

    def test_unit_normalization(self):
        # Grams to kg
        rec_g = HarvestRecord("Basil", "Herb", 500, "g", "2026-08-15", "Bed-1")
        self.assertEqual(rec_g.normalized_kg, 0.5)

        # Pounds to kg
        rec_lbs = HarvestRecord("Squash", "Vegetable", 10, "lbs", "2026-08-15", "Bed-1")
        self.assertAlmostEqual(rec_lbs.normalized_kg, 4.5359, places=3)

        # Ounces to kg
        rec_oz = HarvestRecord("Rosemary", "Herb", 16, "oz", "2026-08-15", "Bed-1")
        self.assertAlmostEqual(rec_oz.normalized_kg, 0.4536, places=3)

        # Discrete items (bunches, pcs)
        rec_pcs = HarvestRecord("Corn", "Vegetable", 12, "pcs", "2026-08-15", "Bed-1")
        self.assertEqual(rec_pcs.normalized_kg, 12.0)
        self.assertFalse(rec_pcs.is_weight_unit)

    def test_serialization_round_trip(self):
        rec = HarvestRecord("Kale", "Leafy Green", 8, "bunches", "2026-08-15", "Bed-2", QualityGrade.GRADE_A.value, 16.0)
        data = rec.to_dict()
        reconstituted = HarvestRecord.from_dict(data)
        self.assertEqual(rec.id, reconstituted.id)
        self.assertEqual(rec.crop_name, reconstituted.crop_name)
        self.assertEqual(rec.quantity, reconstituted.quantity)
        self.assertEqual(rec.unit, reconstituted.unit)


if __name__ == "__main__":
    unittest.main()
