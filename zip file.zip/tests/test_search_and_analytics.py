"""Unit tests for query engine, analytics, and bulk CSV importer."""

import unittest
from datetime import date
from garden_harvest.models import HarvestRecord, QualityGrade
from garden_harvest.search import QueryEngine
from garden_harvest.analytics import AnalyticsEngine
from garden_harvest.bulk_importer import BulkDatasetImporter


class TestSearchAndAnalytics(unittest.TestCase):

    def setUp(self):
        self.records = [
            HarvestRecord("Roma Tomatoes", "Fruit", 15.0, "kg", "2026-08-01", "Bed-1", QualityGrade.GRADE_A.value, 45.0, "Sweet"),
            HarvestRecord("Lacinato Kale", "Leafy Green", 10, "bunches", "2026-08-05", "Bed-2", QualityGrade.GRADE_A.value, 20.0),
            HarvestRecord("Zucchini", "Vegetable", 8.0, "kg", "2026-08-10", "Bed-3", QualityGrade.GRADE_B.value, 16.0),
            HarvestRecord("Damaged Apples", "Fruit", 3.0, "kg", "2026-08-12", "Bed-1", QualityGrade.DAMAGED.value, 0.0, "Hail damage"),
        ]

    def test_query_filter_by_keyword(self):
        res = QueryEngine.filter_records(self.records, keyword="sweet")
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0].crop_name, "Roma Tomatoes")

    def test_query_filter_by_category(self):
        res = QueryEngine.filter_records(self.records, category="Fruit")
        self.assertEqual(len(res), 2)

    def test_query_filter_by_date_range(self):
        res = QueryEngine.filter_records(self.records, date_from="2026-08-04", date_to="2026-08-11")
        self.assertEqual(len(res), 2)

    def test_pagination(self):
        items, pages, count = QueryEngine.paginate(self.records, page=1, page_size=2)
        self.assertEqual(len(items), 2)
        self.assertEqual(pages, 2)
        self.assertEqual(count, 4)

    def test_executive_summary_kpis(self):
        summary = AnalyticsEngine.generate_executive_summary(self.records, weekly_target_kg=15.0)
        self.assertEqual(summary["total_records"], 4)
        self.assertEqual(summary["total_weight_kg"], 26.0)
        self.assertEqual(summary["total_count_items"], 10)
        self.assertEqual(summary["total_estimated_value"], 81.0)
        self.assertEqual(summary["average_weekly_kg"], 8.67)
        self.assertIn("Below Target", summary["status_indicators"]["yield_health"])
        self.assertEqual(len(summary["top_crops_weight"]), 4)

        # When target is adjusted lower, indicator shifts to Target Exceeded
        summary_low_target = AnalyticsEngine.generate_executive_summary(self.records, weekly_target_kg=7.0)
        self.assertIn("Target Exceeded", summary_low_target["status_indicators"]["yield_health"])

    def test_threshold_warning_detection(self):
        # r4 is damaged 3.0kg, which should trigger a spoilage warning
        warnings = AnalyticsEngine.detect_threshold_warnings(self.records)
        self.assertTrue(any(w["code"] == "SPOILAGE_LOSS" for w in warnings))


if __name__ == "__main__":
    unittest.main()
