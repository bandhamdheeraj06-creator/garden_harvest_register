"""Unit tests for defensive input validation and domain constraints."""

import unittest
from datetime import date, timedelta
from garden_harvest.validation import (
    validate_crop_name,
    validate_date,
    validate_category,
    validate_quantity,
    validate_unit,
    validate_bed_id,
    validate_quality_grade,
    validate_estimated_value,
    sanitize_text
)


class TestValidation(unittest.TestCase):

    def test_crop_name_validation(self):
        # Valid cases
        self.assertTrue(validate_crop_name("San Marzano Tomatoes")[0])
        self.assertTrue(validate_crop_name("Early Girl (F1)")[0])
        self.assertTrue(validate_crop_name("Carrots - Nantes")[0])

        # Invalid cases
        self.assertFalse(validate_crop_name("")[0])
        self.assertFalse(validate_crop_name("   ")[0])
        self.assertFalse(validate_crop_name("A")[0])  # Too short
        self.assertFalse(validate_crop_name("<script>alert(1)</script>")[0])

    def test_date_validation(self):
        # Valid cases
        self.assertTrue(validate_date("2026-08-15")[0])
        self.assertTrue(validate_date("2024-02-29")[0])  # Valid leap year

        # Invalid cases
        self.assertFalse(validate_date("")[0])
        self.assertFalse(validate_date("invalid-date")[0])
        self.assertFalse(validate_date("2025-02-29")[0])  # Not a leap year
        self.assertFalse(validate_date("1995-05-10")[0])  # Year < 2000
        # Far future
        far_future = (date.today() + timedelta(days=45)).isoformat()
        self.assertFalse(validate_date(far_future)[0])

    def test_quantity_validation(self):
        # Valid cases
        ok, val, _ = validate_quantity(15.5)
        self.assertTrue(ok)
        self.assertEqual(val, 15.5)

        ok_str, val_str, _ = validate_quantity(" 8.25 ")
        self.assertTrue(ok_str)
        self.assertEqual(val_str, 8.25)

        # Boundary small quantity
        self.assertTrue(validate_quantity(0.005)[0])

        # Invalid cases
        self.assertFalse(validate_quantity(0.0)[0])
        self.assertFalse(validate_quantity(-5.0)[0])
        self.assertFalse(validate_quantity("five")[0])
        self.assertFalse(validate_quantity(60000.0)[0])  # Exceeds max limit

    def test_unit_validation(self):
        self.assertTrue(validate_unit("kg")[0])
        self.assertTrue(validate_unit("g")[0])
        self.assertTrue(validate_unit("lbs")[0])
        self.assertTrue(validate_unit("oz")[0])
        self.assertTrue(validate_unit("pcs")[0])
        self.assertTrue(validate_unit("bunches")[0])

        # Aliases
        ok, mapped, _ = validate_unit("Kilograms")
        self.assertTrue(ok)
        self.assertEqual(mapped, "kg")

        # Invalid
        self.assertFalse(validate_unit("gallons")[0])
        self.assertFalse(validate_unit("")[0])

    def test_bed_id_validation(self):
        self.assertTrue(validate_bed_id("Bed-1")[0])
        self.assertTrue(validate_bed_id("Greenhouse North #2")[0])
        self.assertFalse(validate_bed_id("")[0])

    def test_financial_value_validation(self):
        ok, val, _ = validate_estimated_value("$24.50")
        self.assertTrue(ok)
        self.assertEqual(val, 24.5)

        ok_zero, val_zero, _ = validate_estimated_value(0)
        self.assertTrue(ok_zero)
        self.assertEqual(val_zero, 0.0)

        self.assertFalse(validate_estimated_value(-10.0)[0])
        self.assertFalse(validate_estimated_value("free")[0])

    def test_sanitization(self):
        dirty = "Roma Tomatoes\x00\x08   "
        self.assertEqual(sanitize_text(dirty), "Roma Tomatoes")


if __name__ == "__main__":
    unittest.main()
