"""🌿 Garden Harvest Register - Ultimate Web Dashboard
Project #67: Everyday Innovators | Domain: Food & Agriculture
Framework: Streamlit & Altair Visualizations
"""

import os
import sys
import json
from pathlib import Path
from datetime import date, datetime, timedelta
import pandas as pd
import numpy as np
import altair as alt
import streamlit as st

# Setup project path
project_root = Path(__file__).resolve().parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from garden_harvest.models import HarvestRecord, CropCategory, QualityGrade, HarvestUnit
from garden_harvest.validation import (
    validate_crop_name,
    validate_date,
    validate_category,
    validate_quantity,
    validate_unit,
    validate_bed_id,
    validate_quality_grade,
    validate_estimated_value,
    sanitize_text
)
from garden_harvest.persistence import StorageManager
from garden_harvest.business_logic import BusinessLogicEngine
from garden_harvest.search import QueryEngine
from garden_harvest.analytics import AnalyticsEngine
from garden_harvest.exporter import ReportExporter
from garden_harvest.bulk_importer import BulkDatasetImporter

# -----------------------------------------------------------------------------
# PAGE CONFIGURATION
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="Garden Harvest Register | Smart Agro Analytics",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded"
)

# -----------------------------------------------------------------------------
# CUSTOM CSS AESTHETICS & AGRO-TECH PALETTE
# -----------------------------------------------------------------------------
st.markdown("""
<style>
    /* Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
    }

    /* Gradient Brand Header */
    .hero-banner {
        background: linear-gradient(135deg, #134e2b 0%, #1e6f42 50%, #2a9d5c 100%);
        color: white;
        padding: 24px 30px;
        border-radius: 16px;
        margin-bottom: 24px;
        box-shadow: 0 10px 25px -5px rgba(27, 94, 32, 0.25);
    }
    .hero-title {
        font-size: 2.1rem;
        font-weight: 800;
        margin: 0;
        letter-spacing: -0.5px;
        color: #ffffff;
    }
    .hero-sub {
        font-size: 1.0rem;
        opacity: 0.92;
        margin-top: 6px;
        font-weight: 400;
    }
    .badge-pill {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.78rem;
        font-weight: 700;
        background: rgba(255, 255, 255, 0.2);
        color: white;
        margin-right: 8px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* KPI Metric Cards */
    .metric-card {
        background: #ffffff;
        border-radius: 14px;
        padding: 18px 20px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
        transition: transform 0.15s ease, box-shadow 0.15s ease;
    }
    .metric-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
    }
    .metric-label {
        font-size: 0.82rem;
        font-weight: 600;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 4px;
    }
    .metric-value {
        font-size: 1.85rem;
        font-weight: 800;
        color: #0f172a;
        line-height: 1.2;
    }
    .metric-delta {
        font-size: 0.8rem;
        font-weight: 600;
        margin-top: 6px;
    }
    .delta-green { color: #16a34a; }
    .delta-blue { color: #2563eb; }
    .delta-amber { color: #d97706; }

    /* Section Headings */
    .section-title {
        font-size: 1.25rem;
        font-weight: 700;
        color: #1e293b;
        margin: 22px 0 14px 0;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    /* Left Sidebar Navigation Custom Styling */
    section[data-testid="stSidebar"] {
        background-color: #f8fafc;
        border-right: 1px solid #e2e8f0;
    }

    /* Hide standard radio circles in sidebar */
    section[data-testid="stSidebar"] div[role="radiogroup"] > label > div:first-child {
        display: none !important;
    }

    /* Transform radio options into modern interactive nav tiles */
    section[data-testid="stSidebar"] div[role="radiogroup"] {
        gap: 7px;
        display: flex;
        flex-direction: column;
        padding-top: 2px;
    }

    section[data-testid="stSidebar"] div[role="radiogroup"] > label {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 11px;
        padding: 11px 16px;
        margin: 0 !important;
        cursor: pointer;
        transition: all 0.18s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02);
        display: flex;
        align-items: center;
        width: 100%;
    }

    section[data-testid="stSidebar"] div[role="radiogroup"] > label:hover {
        background: #f0fdf4;
        border-color: #86efac;
        transform: translateX(4px);
        box-shadow: 0 4px 12px rgba(34, 197, 94, 0.08);
    }

    section[data-testid="stSidebar"] div[role="radiogroup"] > label p {
        font-size: 0.92rem;
        font-weight: 600;
        color: #334155;
        margin: 0;
    }

    /* Active Nav Item Tile */
    section[data-testid="stSidebar"] div[role="radiogroup"] > label:has(input:checked) {
        background: linear-gradient(135deg, #1b4332 0%, #2d6a4f 100%) !important;
        border-color: #1b4332 !important;
        box-shadow: 0 6px 16px rgba(27, 67, 50, 0.28) !important;
        transform: translateX(5px);
    }

    section[data-testid="stSidebar"] div[role="radiogroup"] > label:has(input:checked) p {
        color: #ffffff !important;
        font-weight: 700 !important;
    }

    /* Live Preview Card */
    .preview-box {
        background: #f8fafc;
        border: 2px dashed #cbd5e1;
        border-radius: 12px;
        padding: 18px;
        margin-top: 15px;
    }

    /* Alert Indicators */
    .alert-card {
        border-radius: 10px;
        padding: 12px 16px;
        margin-bottom: 10px;
        font-size: 0.9rem;
    }
    .alert-critical {
        background: #fef2f2;
        border-left: 4px solid #ef4444;
        color: #991b1b;
    }
    .alert-high {
        background: #fffbeb;
        border-left: 4px solid #f59e0b;
        color: #92400e;
    }
    .alert-medium {
        background: #eff6ff;
        border-left: 4px solid #3b82f6;
        color: #1e40af;
    }
</style>
""", unsafe_allow_html=True)


# -----------------------------------------------------------------------------
# DATA ACCESS & STORAGE CACHING
# -----------------------------------------------------------------------------
@st.cache_resource
def get_storage():
    return StorageManager()


storage = get_storage()


def get_fresh_data():
    records, warnings = storage.load_records()
    data = [r.to_dict() for r in records]
    df = pd.DataFrame(data) if data else pd.DataFrame(columns=[
        "id", "harvest_date", "crop_name", "category", "quantity",
        "unit", "normalized_kg", "bed_id", "quality_grade", "estimated_value", "notes", "week_key"
    ])
    if not df.empty and "harvest_date" in df.columns:
        df["parsed_date"] = pd.to_datetime(df["harvest_date"])
    return records, df, warnings


records, df, storage_warnings = get_fresh_data()


# -----------------------------------------------------------------------------
# HERO BRAND BANNER
# -----------------------------------------------------------------------------
st.markdown("""
<div class="hero-banner">
    <div>
        <span class="badge-pill">Project #67</span>
        <span class="badge-pill">Food & Agriculture</span>
        <span class="badge-pill">Everyday Innovators</span>
        <span class="badge-pill">Python 3.10+ Standard</span>
    </div>
    <h1 class="hero-title">🌿 Garden Harvest Register</h1>
    <div class="hero-sub">Smart Agro-Data Capture, ISO Weekly Yield Aggregations, and Executive Crop Analytics</div>
</div>
""", unsafe_allow_html=True)

if storage_warnings:
    for w in storage_warnings:
        st.warning(f"⚠️ **Storage Notice:** {w}")


# -----------------------------------------------------------------------------
# SIDEBAR NAVIGATION & OPERATIONS DRAWER
# -----------------------------------------------------------------------------
# Sidebar Brand Header
st.sidebar.markdown("""
<div style="display:flex;align-items:center;gap:12px;padding:4px 0 16px 0;margin-bottom:14px;border-bottom:1px solid #e2e8f0;">
    <div style="background:linear-gradient(135deg,#1b4332,#2d6a4f);color:white;width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;box-shadow:0 4px 12px rgba(27,67,50,0.25);">🌿</div>
    <div>
        <div style="font-weight:800;font-size:1.12rem;color:#0f172a;line-height:1.2;">Garden Harvest</div>
        <div style="font-size:0.75rem;font-weight:700;color:#16a34a;text-transform:uppercase;letter-spacing:0.5px;">Register • Project #67</div>
    </div>
</div>
""", unsafe_allow_html=True)

st.sidebar.markdown("<div style='font-size:0.74rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:8px;'>Navigation Menu</div>", unsafe_allow_html=True)

nav_options = [
    "📊 Executive Dashboard",
    "➕ Record Harvest",
    "🔍 Records Explorer",
    "📅 Weekly Trends",
    "📥 Bulk CSV Ingestion",
    "📑 Report Exporter"
]

nav_choice = st.sidebar.radio(
    "Navigation Menu",
    options=nav_options,
    index=0,
    label_visibility="collapsed"
)

st.sidebar.markdown("<hr style='margin: 18px 0 14px 0; border: none; border-top: 1px solid #e2e8f0;'/>", unsafe_allow_html=True)
st.sidebar.markdown("<div style='font-size:0.74rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:8px;'>Operational Controls</div>", unsafe_allow_html=True)

# System Status Card
st.sidebar.markdown(f"""
<div style="background:#f1f5f9;border-radius:10px;padding:12px;margin-bottom:14px;border:1px solid #cbd5e1;">
    <div style="font-size:0.72rem;font-weight:700;color:#64748b;text-transform:uppercase;">Storage Engine</div>
    <div style="font-size:1.02rem;font-weight:800;color:#0f172a;margin:2px 0;">Dual JSON + CSV</div>
    <div style="font-size:0.82rem;color:#475569;">Active Records: <b>{len(records)}</b></div>
</div>
""", unsafe_allow_html=True)

weekly_target_setting = st.sidebar.slider(
    "Weekly Target Yield (kg)",
    min_value=10.0,
    max_value=100.0,
    value=25.0,
    step=2.5,
    help="Configurable operational threshold for weekly production health assessment"
)

st.sidebar.markdown("<hr style='margin: 14px 0; border: none; border-top: 1px solid #e2e8f0;'/>", unsafe_allow_html=True)
st.sidebar.markdown("<div style='font-size:0.74rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:8px;'>Rapid Actions</div>", unsafe_allow_html=True)

c_act1, c_act2 = st.sidebar.columns(2)
with c_act1:
    if st.sidebar.button("🔄 Sync", use_container_width=True, help="Reload database from disk"):
        st.cache_resource.clear()
        st.rerun()
with c_act2:
    if st.sidebar.button("📑 Export", use_container_width=True, help="Generate all report formats"):
        export_dir = storage.data_dir.parent / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)
        ReportExporter.export_markdown_report(records, str(export_dir / "quick_export_report.md"), weekly_target_kg=weekly_target_setting)
        storage.export_csv(records, str(export_dir / "quick_export_database.csv"))
        st.sidebar.success("Exported to exports/")

st.sidebar.markdown("<hr style='margin: 14px 0; border: none; border-top: 1px solid #e2e8f0;'/>", unsafe_allow_html=True)
st.sidebar.markdown(f"**Domain:** Food & Agriculture")
st.sidebar.markdown(f"**Project:** Everyday Innovators #67")
st.sidebar.markdown(f"**Workspace:** [garden_harvest_register](file:///{storage.data_dir.parent.as_posix()})")


# =============================================================================
# MODULE 1: EXECUTIVE YIELD DASHBOARD
# =============================================================================
if nav_choice == "📊 Executive Dashboard":
    summary = AnalyticsEngine.generate_executive_summary(records, weekly_target_kg=weekly_target_setting)
    warnings = AnalyticsEngine.detect_threshold_warnings(records, target_weekly_kg=weekly_target_setting)
    weekly_data = summary["weekly_totals"]

    # 5 KPI Metric Cards
    m1, m2, m3, m4, m5 = st.columns(5)
    with m1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">🌾 Total Net Yield</div>
            <div class="metric-value">{summary['total_weight_kg']:.1f} <span style="font-size:1rem;color:#64748b">kg</span></div>
            <div class="metric-delta delta-green">across {summary['total_records']} logged events</div>
        </div>
        """, unsafe_allow_html=True)

    with m2:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">📦 Discrete Units</div>
            <div class="metric-value">{summary['total_count_items']} <span style="font-size:1rem;color:#64748b">pcs</span></div>
            <div class="metric-delta delta-blue">bunches &amp; head counts</div>
        </div>
        """, unsafe_allow_html=True)

    with m3:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">💰 Market Valuation</div>
            <div class="metric-value">${summary['total_estimated_value']:.2f}</div>
            <div class="metric-delta delta-green">Avg ${summary['total_estimated_value']/max(1, summary['total_records']):.2f} / entry</div>
        </div>
        """, unsafe_allow_html=True)

    with m4:
        delta_class = "delta-green" if summary['average_weekly_kg'] >= weekly_target_setting else "delta-amber"
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">📈 Avg Weekly Pace</div>
            <div class="metric-value">{summary['average_weekly_kg']:.1f} <span style="font-size:1rem;color:#64748b">kg</span></div>
            <div class="metric-delta {delta_class}">Target: {weekly_target_setting:.1f} kg/wk</div>
        </div>
        """, unsafe_allow_html=True)

    with m5:
        spoil_pct = summary['spoilage_rate_pct']
        spoil_class = "delta-green" if spoil_pct <= 4.0 else ("delta-amber" if spoil_pct <= 10.0 else "delta-critical")
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">🛡️ Spoilage Index</div>
            <div class="metric-value">{spoil_pct:.1f}%</div>
            <div class="metric-delta {spoil_class}">{summary['damaged_kg']:.1f} kg damaged / lost</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Operational Status Pill Banner
    stat1, stat2, stat3 = st.columns(3)
    with stat1:
        st.info(f"**Yield Health:** {summary['status_indicators']['yield_health']}")
    with stat2:
        st.info(f"**Spoilage Level:** {summary['status_indicators']['spoilage_level']}")
    with stat3:
        st.info(f"**Season Velocity:** {summary['status_indicators']['season_momentum']}")

    st.markdown("<div class=\"section-title\">📈 Chronological Weekly Harvest Trends</div>", unsafe_allow_html=True)

    if weekly_data:
        chart_records = []
        for w in weekly_data:
            chart_records.append({
                "Week": w["week_key"],
                "Weight_kg": w["total_weight_kg"],
                "Valuation": w["total_value"],
                "Trend": w["trend_symbol"],
                "Top_Crop": list(w["by_crop"].keys())[0] if w["by_crop"] else "N/A",
                "Window": f"{w['start_date']} to {w['end_date']}"
            })
        w_df = pd.DataFrame(chart_records)

        # Altair Dual Chart: Bars for Weekly Yield + Target Line
        base = alt.Chart(w_df).encode(x=alt.X("Week:N", sort=None, title="Calendar Week (ISO)"))

        bars = base.mark_bar(cornerRadiusTopLeft=6, cornerRadiusTopRight=6, color="#2d6a4f").encode(
            y=alt.Y("Weight_kg:Q", title="Harvest Weight (kg)"),
            tooltip=[
                alt.Tooltip("Week:N", title="ISO Week"),
                alt.Tooltip("Window:N", title="Date Window"),
                alt.Tooltip("Weight_kg:Q", title="Total Yield (kg)", format=".2f"),
                alt.Tooltip("Valuation:Q", title="Market Value ($)", format="$.2f"),
                alt.Tooltip("Trend:N", title="Growth Trend"),
                alt.Tooltip("Top_Crop:N", title="Leading Crop")
            ]
        )

        target_line = alt.Chart(pd.DataFrame({"Target": [weekly_target_setting]})).mark_rule(
            color="#ef4444", strokeDash=[6, 4], size=2
        ).encode(y="Target:Q")

        trend_chart = (bars + target_line).properties(height=320)
        st.altair_chart(trend_chart, use_container_width=True)

    # Middle Row: Category Distribution & Garden Bed Yield
    col_pie, col_bed = st.columns([1, 1])

    with col_pie:
        st.markdown("<div class=\"section-title\">🥕 Category Distribution (Yield Share)</div>", unsafe_allow_html=True)
        cat_data = BusinessLogicEngine.calculate_category_breakdown(records)
        cat_chart_df = pd.DataFrame([
            {"Category": k, "Yield_kg": v["total_kg"], "Valuation": v["total_value"]}
            for k, v in cat_data.items() if v["total_kg"] > 0
        ])
        if not cat_chart_df.empty:
            donut = alt.Chart(cat_chart_df).mark_arc(innerRadius=65, stroke="#ffffff", strokeWidth=2).encode(
                theta=alt.Theta("Yield_kg:Q"),
                color=alt.Color("Category:N", scale=alt.Scale(scheme="category10"), legend=alt.Legend(orient="bottom", columns=3)),
                tooltip=[
                    alt.Tooltip("Category:N"),
                    alt.Tooltip("Yield_kg:Q", title="Total kg", format=".1f"),
                    alt.Tooltip("Valuation:Q", title="Value ($)", format="$.2f")
                ]
            ).properties(height=280)
            st.altair_chart(donut, use_container_width=True)

    with col_bed:
        st.markdown("<div class=\"section-title\">🏡 Garden Bed & Plot Productivity</div>", unsafe_allow_html=True)
        bed_data = BusinessLogicEngine.calculate_bed_yields(records)
        bed_chart_df = pd.DataFrame([
            {"Plot": k, "Yield_kg": v["total_kg"], "Entries": v["entries"], "Spoilage": v["spoilage_rate_pct"]}
            for k, v in bed_data.items()
        ]).sort_values("Yield_kg", ascending=True)

        if not bed_chart_df.empty:
            bed_bars = alt.Chart(bed_chart_df).mark_bar(cornerRadiusTopRight=4, cornerRadiusBottomRight=4, color="#1e6f42").encode(
                x=alt.X("Yield_kg:Q", title="Cumulative Yield (kg)"),
                y=alt.Y("Plot:N", sort=None, title="Plot / Bed"),
                tooltip=[
                    alt.Tooltip("Plot:N"),
                    alt.Tooltip("Yield_kg:Q", title="Total Yield (kg)", format=".2f"),
                    alt.Tooltip("Entries:Q", title="Harvest Events"),
                    alt.Tooltip("Spoilage:Q", title="Spoilage Rate (%)", format=".1f")
                ]
            ).properties(height=280)
            st.altair_chart(bed_bars, use_container_width=True)

    # Bottom Row: Top 5 Crop Variety Leaderboard & Automated Warnings
    c_lead, c_warn = st.columns([1, 1])

    with c_lead:
        st.markdown("<div class=\"section-title\">🏆 Top 5 Performing Crops by Weight</div>", unsafe_allow_html=True)
        top_crops = summary.get("top_crops_weight", [])
        for rank, tc in enumerate(top_crops[:5], 1):
            pct_val = tc["pct"] / 100.0
            col_cr_name, col_cr_bar, col_cr_kg = st.columns([2, 3, 1])
            with col_cr_name:
                st.write(f"**{rank}. {tc['crop']}**")
            with col_cr_bar:
                st.progress(min(1.0, max(0.0, pct_val)))
            with col_cr_kg:
                st.write(f"{tc['kg']:.1f} kg ({tc['pct']}%)")

    with c_warn:
        st.markdown("<div class=\"section-title\">⚠️ Automated Threshold Warning Feed</div>", unsafe_allow_html=True)
        if warnings:
            for w in warnings:
                sev = w["severity"].lower()
                sev_class = "alert-critical" if sev == "critical" else ("alert-high" if sev == "high" else "alert-medium")
                st.markdown(f"""
                <div class="alert-card {sev_class}">
                    <b>[{w['severity']}] {w['code']}</b><br>
                    {w['message']}
                </div>
                """, unsafe_allow_html=True)
        else:
            st.success("✅ All agricultural harvest metrics are operating within normal baseline bounds!")


# =============================================================================
# MODULE 2: RECORD HARVEST (LIVE WIZARD WITH REAL-TIME PREVIEW)
# =============================================================================
elif nav_choice == "➕ Record Harvest":
    st.markdown("<div class=\"section-title\">➕ Smart Harvest Intake Wizard</div>", unsafe_allow_html=True)
    st.write("Defensive sanitization, domain boundary checks, and automatic kilogram normalizations are active.")

    col_form, col_prev = st.columns([3, 2])

    with col_form:
        with st.form("smart_intake_form", clear_on_submit=False):
            f_col1, f_col2 = st.columns(2)
            with f_col1:
                in_crop = st.text_input("Crop Variety *", value="San Marzano Tomatoes", help="Produce variety name (e.g. Roma Tomatoes, Lacinato Kale)")
                in_cat = st.selectbox("Category *", CropCategory.list_values(), index=0)
                in_date = st.date_input("Harvest Date *", value=date.today())
                in_bed = st.text_input("Garden Bed / Plot *", value="Bed-1", help="Plot ID (e.g. Bed-1, Greenhouse-North, Raised-Bed-A)")

            with f_col2:
                q_c1, q_c2 = st.columns([2, 1])
                with q_c1:
                    in_qty = st.number_input("Quantity *", min_value=0.001, max_value=50000.0, value=12.5, step=0.5)
                with q_c2:
                    in_unit = st.selectbox("Unit *", HarvestUnit.list_values(), index=0)

                in_grade = st.selectbox("Quality Inspection *", QualityGrade.list_values(), index=0)
                in_val = st.number_input("Estimated Value ($)", min_value=0.0, max_value=10000.0, value=37.5, step=1.0)

            in_notes = st.text_area("Field Notes / Weather Observations (Optional)", placeholder="e.g. Sunny morning pick, minimal insect activity...", height=70)

            btn_submit = st.form_submit_button("🌱 Save & Persist Harvest Record", type="primary", use_container_width=True)

            if btn_submit:
                ok_crop, v_crop, err_crop = validate_crop_name(in_crop)
                ok_date, v_date, err_date = validate_date(in_date.isoformat())
                ok_qty, v_qty, err_qty = validate_quantity(in_qty)
                ok_bed, v_bed, err_bed = validate_bed_id(in_bed)
                ok_val, v_val, err_val = validate_estimated_value(in_val)

                errors = []
                if not ok_crop: errors.append(f"Crop Error: {err_crop}")
                if not ok_date: errors.append(f"Date Error: {err_date}")
                if not ok_qty: errors.append(f"Quantity Error: {err_qty}")
                if not ok_bed: errors.append(f"Bed Error: {err_bed}")
                if not ok_val: errors.append(f"Value Error: {err_val}")

                if errors:
                    for e in errors:
                        st.error(f"❌ {e}")
                else:
                    new_rec = HarvestRecord(
                        crop_name=v_crop,
                        category=in_cat,
                        quantity=v_qty,
                        unit=in_unit,
                        harvest_date=v_date,
                        bed_id=v_bed,
                        quality_grade=in_grade,
                        estimated_value=v_val,
                        notes=sanitize_text(in_notes)
                    )
                    records.append(new_rec)
                    storage.save_records(records)
                    st.balloons()
                    st.success(f"✅ Successfully Logged & Persisted: **{new_rec.crop_name}** ({new_rec.quantity} {new_rec.unit} = {new_rec.normalized_kg:.2f} kg) in `{new_rec.bed_id}`! Week: `{new_rec.week_key}`")
                    st.cache_resource.clear()

    with col_prev:
        st.markdown("<div class=\"section-title\">🔍 Live Transaction Preview</div>", unsafe_allow_html=True)
        # Compute real-time normalized preview
        preview_kg = HarvestUnit.normalize_to_kg(in_qty, in_unit)
        cal = in_date.isocalendar()
        week_preview = f"{cal[0]}-W{cal[1]:02d}"

        st.markdown(f"""
        <div class="preview-box">
            <h4 style="margin-top:0;color:#1e6f42;">🌿 {in_crop if in_crop else 'Pending Entry'}</h4>
            <table style="width:100%;font-size:0.9rem;border-collapse:collapse;">
                <tr><td style="color:#64748b;padding:4px 0;">Category:</td><td><b>{in_cat}</b></td></tr>
                <tr><td style="color:#64748b;padding:4px 0;">Recorded Qty:</td><td><b>{in_qty:g} {in_unit}</b></td></tr>
                <tr><td style="color:#64748b;padding:4px 0;">Normalized Weight:</td><td><b style="color:#16a34a;">{preview_kg:.2f} kg</b></td></tr>
                <tr><td style="color:#64748b;padding:4px 0;">Harvest Date:</td><td><b>{in_date.isoformat()}</b></td></tr>
                <tr><td style="color:#64748b;padding:4px 0;">Assigned Week:</td><td><span style="background:#e2e8f0;padding:2px 8px;border-radius:4px;font-weight:700;">{week_preview}</span></td></tr>
                <tr><td style="color:#64748b;padding:4px 0;">Plot Location:</td><td><b>{in_bed}</b></td></tr>
                <tr><td style="color:#64748b;padding:4px 0;">Quality Rating:</td><td><b>{in_grade}</b></td></tr>
                <tr><td style="color:#64748b;padding:4px 0;">Estimated Valuation:</td><td><b>${in_val:.2f}</b></td></tr>
            </table>
        </div>
        """, unsafe_allow_html=True)


# =============================================================================
# MODULE 3: RECORDS EXPLORER & SEARCH
# =============================================================================
elif nav_choice == "🔍 Records Explorer":
    st.markdown("<div class=\"section-title\">📋 Harvest Records Explorer & Multi-Parameter Filter</div>", unsafe_allow_html=True)

    # Search Bar & Filter Row
    s_c1, s_c2, s_c3, s_c4 = st.columns([2, 1, 1, 1])
    with s_c1:
        kw_search = st.text_input("🔍 Keyword Search", "", placeholder="Search crop, plot, ID, notes...")
    with s_c2:
        cat_filter = st.selectbox("Category", ["All"] + CropCategory.list_values())
    with s_c3:
        all_beds = sorted(list(set(r.bed_id for r in records))) if records else ["All"]
        bed_filter = st.selectbox("Plot / Bed", ["All"] + all_beds)
    with s_c4:
        grade_filter = st.selectbox("Quality Grade", ["All"] + QualityGrade.list_values())

    filtered_records = QueryEngine.filter_records(
        records,
        keyword=kw_search if kw_search else None,
        category=None if cat_filter == "All" else cat_filter,
        bed_id=None if bed_filter == "All" else bed_filter,
        quality_grade=None if grade_filter == "All" else grade_filter,
        sort_by="date",
        reverse=True
    )

    st.write(f"Showing **{len(filtered_records)}** of **{len(records)}** total records.")

    if filtered_records:
        t_data = []
        for r in filtered_records:
            t_data.append({
                "ID": r.id,
                "Date": r.harvest_date,
                "Week": r.week_key,
                "Crop": r.crop_name,
                "Category": r.category,
                "Quantity": f"{r.quantity:g} {r.unit}",
                "Weight (kg)": r.normalized_kg,
                "Plot": r.bed_id,
                "Quality Grade": r.quality_grade,
                "Value ($)": r.estimated_value,
                "Notes": r.notes
            })
        tbl_df = pd.DataFrame(t_data)

        st.dataframe(
            tbl_df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "Weight (kg)": st.column_config.NumberColumn(format="%.2f kg"),
                "Value ($)": st.column_config.NumberColumn(format="$%.2f")
            }
        )

        dl_col1, dl_col2 = st.columns([1, 1])
        with dl_col1:
            csv_str = tbl_df.to_csv(index=False).encode("utf-8")
            st.download_button("💾 Download Filtered View (CSV)", csv_str, "filtered_harvests.csv", "text/csv")
        with dl_col2:
            json_str = json.dumps([r.to_dict() for r in filtered_records], indent=2).encode("utf-8")
            st.download_button("📦 Download Filtered View (JSON)", json_str, "filtered_harvests.json", "application/json")
    else:
        st.warning("No harvest records match your current filter criteria.")


# =============================================================================
# MODULE 4: WEEKLY TOTALS & GROWTH DEEP-DIVE
# =============================================================================
elif nav_choice == "📅 Weekly Trends":
    st.markdown("<div class=\"section-title\">📅 ISO Weekly Totals & Chronological Growth Deep-Dive</div>", unsafe_allow_html=True)
    st.write("Aggregated using ISO calendar weeks with percentage growth rates and category breakdowns.")

    weekly_list = BusinessLogicEngine.calculate_weekly_totals(records)

    if weekly_list:
        # Summary Overview Cards for Weekly Trends
        w_df = pd.DataFrame([
            {
                "ISO Week": w["week_key"],
                "Date Window": f"{w['start_date']} to {w['end_date']}",
                "Net Yield (kg)": w["total_weight_kg"],
                "Units (pcs)": w["total_items_count"],
                "Valuation ($)": w["total_value"],
                "Growth Trend": w["trend_symbol"],
                "Top Crop": list(w["by_crop"].keys())[0] if w["by_crop"] else "N/A",
                "Harvest Events": w["harvest_count"],
                "Spoilage Rate": f"{w['spoilage_rate_pct']:.1f}%"
            }
            for w in weekly_list
        ])

        st.dataframe(w_df, use_container_width=True, hide_index=True)

        st.markdown("<div class=\"section-title\">🔍 Week-by-Week Crop Details</div>", unsafe_allow_html=True)
        for w in reversed(weekly_list):
            with st.expander(f"🌿 **{w['week_key']}** ({w['start_date']} to {w['end_date']}) — **{w['total_weight_kg']:.2f} kg** | Trend: {w['trend_symbol']}"):
                exp_c1, exp_c2 = st.columns(2)
                with exp_c1:
                    st.write("##### Produce Varieties Harvested:")
                    for crop, kg in w["by_crop"].items():
                        st.write(f"- **{crop}**: {kg:.2f} kg")

                with exp_c2:
                    st.write("##### Plot Harvest Breakdown:")
                    for bed, bkg in w["by_bed"].items():
                        st.write(f"- **{bed}**: {bkg:.2f} kg")


# =============================================================================
# MODULE 5: BULK LEGACY CSV INGESTION
# =============================================================================
elif nav_choice == "📥 Bulk CSV Ingestion":
    st.markdown("<div class=\"section-title\">📥 Ingest Legacy CSV Spreadsheets</div>", unsafe_allow_html=True)
    st.write("Upload historical harvest records. The ingestion engine aligns header aliases and executes row-by-row validation with error logs.")

    sample_legacy_path = storage.data_dir / "legacy_import_sample.csv"
    if sample_legacy_path.exists():
        with open(sample_legacy_path, "rb") as f:
            st.download_button(
                "📥 Download Test Dataset with Mixed Rows (Valid & Errors)",
                f.read(),
                file_name="legacy_import_sample.csv",
                mime="text/csv",
                help="Test dataset containing normal rows and intentional edge error cases to test logging"
            )

    uploaded_file = st.file_uploader("Drop your legacy harvest CSV file here", type=["csv"])

    if uploaded_file is not None:
        tmp_path = storage.data_dir / f"uploaded_{uploaded_file.name}"
        with open(tmp_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        res = BulkDatasetImporter.import_csv(str(tmp_path))

        b1, b2, b3, b4 = st.columns(4)
        b1.metric("Rows Processed", res.total_rows)
        b2.metric("Valid Ingested", res.success_count)
        b3.metric("Row Errors Caught", res.error_count)
        b4.metric("Validation Accuracy", f"{res.success_rate}%")

        if res.row_errors:
            st.markdown("##### ⚠️ Row-by-Row Validation Error Inspection")
            st.dataframe(pd.DataFrame(res.row_errors)[["row_number", "field", "error"]], use_container_width=True, hide_index=True)

        if res.imported_records:
            st.markdown("##### ✅ Validated Records Preview")
            preview_df = pd.DataFrame([r.to_dict() for r in res.imported_records])
            st.dataframe(preview_df[["harvest_date", "crop_name", "category", "quantity", "unit", "bed_id", "quality_grade"]], use_container_width=True, hide_index=True)

            if st.button("🚀 Commit Valid Ingested Records to Database", type="primary", use_container_width=True):
                records.extend(res.imported_records)
                storage.save_records(records)
                st.balloons()
                st.success(f"Successfully committed {len(res.imported_records)} records to active storage!")
                st.cache_resource.clear()


# =============================================================================
# MODULE 6: MULTI-FORMAT REPORT EXPORTER
# =============================================================================
elif nav_choice == "📑 Report Exporter":
    st.markdown("<div class=\"section-title\">📑 Multi-Format Export Center</div>", unsafe_allow_html=True)
    st.write("Generate executive reports, audit logs, and datasets ready for evaluation and external review.")

    md_report = ReportExporter.export_markdown_report(records, weekly_target_kg=weekly_target_setting)
    audit_log = ReportExporter.export_audit_log(records)

    c_dl1, c_dl2, c_dl3 = st.columns(3)
    with c_dl1:
        st.download_button(
            "📄 Download Markdown Executive Report (.md)",
            md_report,
            file_name=f"Harvest_Report_{datetime.now().strftime('%Y%m%d')}.md",
            mime="text/markdown",
            use_container_width=True
        )
    with c_dl2:
        st.download_button(
            "🔒 Download Plain-Text Audit Log (.txt)",
            audit_log,
            file_name=f"Harvest_Audit_Log_{datetime.now().strftime('%Y%m%d')}.txt",
            mime="text/plain",
            use_container_width=True
        )
    with c_dl3:
        csv_file_path = storage.data_dir / "harvests.csv"
        if csv_file_path.exists():
            with open(csv_file_path, "r", encoding="utf-8") as f:
                csv_payload = f.read()
            st.download_button(
                "💾 Download Full CSV Database (.csv)",
                csv_payload,
                file_name=f"Harvest_Database_{datetime.now().strftime('%Y%m%d')}.csv",
                mime="text/csv",
                use_container_width=True
            )

    st.markdown("---")
    st.markdown("### 📄 Live Report Preview")
    st.markdown(md_report)
