"""Interactive Terminal Interface with ANSI formatting, defensive validation, and ASCII charts."""

import os
import sys
from datetime import datetime, date
from typing import List, Optional
from .models import HarvestRecord, CropCategory, QualityGrade, HarvestUnit
from .validation import (
    validate_crop_name,
    validate_date,
    validate_category,
    validate_quantity,
    validate_unit,
    validate_bed_id,
    validate_quality_grade,
    validate_estimated_value,
    sanitize_text,
    prompt_validated
)
from .persistence import StorageManager
from .business_logic import BusinessLogicEngine
from .search import QueryEngine
from .analytics import AnalyticsEngine
from .exporter import ReportExporter
from .bulk_importer import BulkDatasetImporter


class TerminalColors:
    """ANSI terminal styling codes."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"

    # Foreground colors
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    # Bright foregrounds
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_WHITE = "\033[97m"

    # Backgrounds
    BG_GREEN = "\033[42m"
    BG_BLUE = "\033[44m"


def colorize(text: str, color_code: str) -> str:
    """Applies ANSI styling to a text string."""
    code = getattr(TerminalColors, color_code.upper(), "")
    return f"{code}{text}{TerminalColors.RESET}" if code else text


class HarvestCLI:
    """Menu-driven interactive console interface for the Garden Harvest Register."""

    def __init__(self, storage_manager: Optional[StorageManager] = None):
        self.storage = storage_manager or StorageManager()
        self.records: List[HarvestRecord] = []
        self.load_state()

    def load_state(self) -> None:
        """Loads records from persistent storage and prints any recovery notices."""
        self.records, warnings = self.storage.load_records()
        for w in warnings:
            print(colorize(f"⚠️  [System Notice]: {w}", "yellow"))

    def display_banner(self) -> None:
        """Renders the branded welcome screen."""
        os.system("cls" if os.name == "nt" else "clear")
        banner = f"""{TerminalColors.BRIGHT_GREEN}
╔═══════════════════════════════════════════════════════════════════════════════╗
║                   🌿  GARDEN HARVEST REGISTER  🌿                             ║
║             Smart Agro-Data Capture & Weekly Yield Analytics                  ║
║             Everyday Innovators Project #67 | Food & Agriculture              ║
╚═══════════════════════════════════════════════════════════════════════════════╝{TerminalColors.RESET}
{TerminalColors.DIM}Active Database: {len(self.records)} records loaded | Local Persistence: JSON + CSV{TerminalColors.RESET}
"""
        print(banner)

    def print_menu(self) -> None:
        """Displays the main navigation options."""
        print(f"\n{TerminalColors.BOLD}══════════════ MAIN NAVIGATION MENU ══════════════{TerminalColors.RESET}")
        print(f"  {colorize('[1]', 'bright_cyan')} Record New Harvest (Defensive Wizard)")
        print(f"  {colorize('[2]', 'bright_cyan')} View All Harvest Records (Formatted Table)")
        print(f"  {colorize('[3]', 'bright_cyan')} Search & Filter Records (Keywords & Dates)")
        print(f"  {colorize('[4]', 'bright_cyan')} Generate Weekly Totals & Growth Trends 📈")
        print(f"  {colorize('[5]', 'bright_cyan')} Executive Summary Dashboard & Status Indicators 🌿")
        print(f"  {colorize('[6]', 'bright_cyan')} Threshold Warning & Anomaly Audit Flags ⚠️")
        print(f"  {colorize('[7]', 'bright_cyan')} Multi-Format Summary Export (Markdown / Audit Log / CSV)")
        print(f"  {colorize('[8]', 'bright_cyan')} Ingest Legacy CSV Dataset (Bulk Import)")
        print(f"  {colorize('[9]', 'bright_magenta')} Launch Desktop GUI (Tkinter Window)")
        print(f"  {colorize('[0]', 'bright_yellow')} Exit Application")
        print(f"{TerminalColors.BOLD}══════════════════════════════════════════════════{TerminalColors.RESET}")

    def run(self) -> None:
        """Main application execution dispatch loop."""
        self.display_banner()
        while True:
            self.print_menu()
            choice = input(f"\n{TerminalColors.BOLD}Select an action [0-9]: {TerminalColors.RESET}").strip()
            print()

            if choice == "1":
                self.record_new_harvest()
            elif choice == "2":
                self.view_records_table(self.records)
            elif choice == "3":
                self.search_records_interactive()
            elif choice == "4":
                self.display_weekly_totals_analytics()
            elif choice == "5":
                self.display_executive_summary()
            elif choice == "6":
                self.display_threshold_warnings()
            elif choice == "7":
                self.export_reports_interactive()
            elif choice == "8":
                self.bulk_import_interactive()
            elif choice == "9":
                self.launch_gui()
            elif choice in ("0", "exit", "quit", "q"):
                print(colorize("🌱 Thank you for cultivating with Garden Harvest Register! Goodbye.", "bright_green"))
                break
            else:
                print(colorize("❌ Invalid selection. Please enter a number between 0 and 9.", "red"))

    # -------------------------------------------------------------------------
    # ACTION HANDLERS
    # -------------------------------------------------------------------------

    def record_new_harvest(self) -> None:
        """Guided interactive input wizard for recording a new harvest with defensive checks."""
        print(f"{TerminalColors.BOLD}🌿 --- RECORD NEW HARVEST ENTRY --- 🌿{TerminalColors.RESET}")
        print(colorize("Strict domain constraints and real-time sanitization active.", "dim"))

        try:
            # 1. Crop Name
            crop_name = prompt_validated(
                "Enter Crop Name (e.g. Roma Tomatoes, Lacinato Kale)",
                validate_crop_name,
                color_fn=colorize
            )

            # 2. Category selection
            print("\nSelect Crop Category:")
            cats = CropCategory.list_values()
            for idx, c in enumerate(cats, 1):
                print(f"  [{idx}] {c}")
            cat_choice = prompt_validated(
                f"Enter Category [1-{len(cats)}] or name",
                lambda val: self._validate_category_choice(val, cats),
                default="1",
                color_fn=colorize
            )

            # 3. Harvest Date
            today_str = date.today().isoformat()
            harvest_date = prompt_validated(
                "Enter Harvest Date (YYYY-MM-DD)",
                validate_date,
                default=today_str,
                color_fn=colorize
            )

            # 4. Quantity
            quantity = prompt_validated(
                "Enter Harvest Quantity (> 0)",
                validate_quantity,
                color_fn=colorize
            )

            # 5. Unit
            units_list = HarvestUnit.list_values()
            print(f"Allowed Units: {', '.join(units_list)}")
            unit = prompt_validated(
                "Enter Unit",
                validate_unit,
                default="kg",
                color_fn=colorize
            )

            # 6. Garden Bed / Plot ID
            bed_id = prompt_validated(
                "Enter Bed / Plot ID (e.g. Bed-1, Greenhouse-A, Raised-Bed-3)",
                validate_bed_id,
                default="Bed-1",
                color_fn=colorize
            )

            # 7. Quality Grade
            print("\nSelect Quality Grade:")
            grades = QualityGrade.list_values()
            for idx, g in enumerate(grades, 1):
                print(f"  [{idx}] {g}")
            grade = prompt_validated(
                f"Enter Quality Grade [1-{len(grades)}] or name",
                lambda val: self._validate_grade_choice(val, grades),
                default="1",
                color_fn=colorize
            )

            # 8. Estimated Financial Value
            est_value = prompt_validated(
                "Enter Estimated Market Value ($ or 0)",
                validate_estimated_value,
                default="0.0",
                color_fn=colorize
            )

            # 9. Notes
            raw_notes = input("Enter Notes / Weather Observations (Optional): ").strip()
            notes = sanitize_text(raw_notes, max_length=200)

            # Construct and Persist Record
            new_rec = HarvestRecord(
                crop_name=crop_name,
                category=cat_choice,
                quantity=quantity,
                unit=unit,
                harvest_date=harvest_date,
                bed_id=bed_id,
                quality_grade=grade,
                estimated_value=est_value,
                notes=notes
            )

            self.records.append(new_rec)
            self.storage.save_records(self.records)

            print(f"\n{TerminalColors.BRIGHT_GREEN}✅ Harvest Record Successfully Logged & Persisted!{TerminalColors.RESET}")
            print(f"  • ID: {colorize(new_rec.id, 'bold')} | Date: {new_rec.harvest_date} | Week: {colorize(new_rec.week_key, 'cyan')}")
            print(f"  • Produce: {new_rec.crop_name} ({new_rec.category})")
            print(f"  • Quantity: {new_rec.quantity} {new_rec.unit} (Normalized: {new_rec.normalized_kg:.2f} kg)")
            print(f"  • Plot: {new_rec.bed_id} | Grade: {new_rec.quality_grade} | Value: ${new_rec.estimated_value:.2f}")

        except (KeyboardInterrupt, EOFError):
            print(colorize("\nEntry recording cancelled.", "yellow"))

    def _validate_category_choice(self, val: str, cats: List[str]):
        if val.isdigit() and 1 <= int(val) <= len(cats):
            return True, cats[int(val) - 1], ""
        return validate_category(val)

    def _validate_grade_choice(self, val: str, grades: List[str]):
        if val.isdigit() and 1 <= int(val) <= len(grades):
            return True, grades[int(val) - 1], ""
        return validate_quality_grade(val)

    def view_records_table(self, records: List[HarvestRecord], page_size: int = 10) -> None:
        """Renders harvest records in a formatted ASCII table with pagination."""
        if not records:
            print(colorize("No harvest records found matching criteria.", "yellow"))
            return

        page = 1
        while True:
            page_records, total_pages, total_count = QueryEngine.paginate(records, page=page, page_size=page_size)

            print(f"\n{TerminalColors.BOLD}HARVEST RECORDS TABLE (Page {page} of {total_pages} | Total: {total_count} records){TerminalColors.RESET}")
            print("┌──────────────┬────────────┬────────────────────┬──────────────┬──────────┬────────────┬─────────────────────┐")
            print("│ Record ID    │ Date       │ Crop Name          │ Quantity     │ Norm. kg │ Bed ID     │ Quality Grade       │")
            print("├──────────────┼────────────┼────────────────────┼──────────────┼──────────┼────────────┼─────────────────────┤")

            for r in page_records:
                qty_display = f"{r.quantity:g} {r.unit}"
                norm_display = f"{r.normalized_kg:.2f}"
                crop_disp = r.crop_name[:18]
                grade_disp = r.quality_grade.split("(")[0].strip()[:19]
                print(
                    f"│ {r.id:<12} │ {r.harvest_date:<10} │ {crop_disp:<18} │ "
                    f"{qty_display:<12} │ {norm_display:<8} │ {r.bed_id[:10]:<10} │ {grade_disp:<19} │"
                )

            print("└──────────────┴────────────┴────────────────────┴──────────────┴──────────┴────────────┴─────────────────────┘")

            if total_pages <= 1:
                break

            nav = input(f"Pagination: [N]ext, [P]revious, or [Q]uit to menu: ").strip().lower()
            if nav == "n" and page < total_pages:
                page += 1
            elif nav == "p" and page > 1:
                page -= 1
            else:
                break

    def search_records_interactive(self) -> None:
        """Interactive search and query prompt."""
        print(f"{TerminalColors.BOLD}🔍 --- QUERY & SEARCH HARVEST RECORDS --- 🔍{TerminalColors.RESET}")
        kw = input("Enter search keyword (crop, bed, notes, or Enter to skip): ").strip()
        cat = input("Enter category filter (or Enter to skip): ").strip()
        bed = input("Enter bed / plot filter (or Enter to skip): ").strip()
        date_from = input("Enter start date YYYY-MM-DD (or Enter to skip): ").strip()
        date_to = input("Enter end date YYYY-MM-DD (or Enter to skip): ").strip()

        filtered = QueryEngine.filter_records(
            self.records,
            keyword=kw if kw else None,
            category=cat if cat else None,
            bed_id=bed if bed else None,
            date_from=date_from if date_from else None,
            date_to=date_to if date_to else None,
            sort_by="date",
            reverse=True
        )

        print(colorize(f"\nFound {len(filtered)} records matching search criteria.", "bright_green"))
        if filtered:
            self.view_records_table(filtered)

    def display_weekly_totals_analytics(self) -> None:
        """Renders weekly totals table, growth rates, and ASCII visual yield charts."""
        weekly_summaries = BusinessLogicEngine.calculate_weekly_totals(self.records)
        if not weekly_summaries:
            print(colorize("No harvest data available to compute weekly totals.", "yellow"))
            return

        print(f"\n{TerminalColors.BOLD}══════════════════════ WEEKLY TOTALS & GROWTH TRENDS ══════════════════════{TerminalColors.RESET}")
        print("┌──────────┬─────────────────────────┬──────────────┬──────────┬───────────┬───────────────┬────────────────┐")
        print("│ Week     │ Date Window (Mon - Sun) │ Net Yield kg │ Units    │ Est Value │ Trend vs Prev │ Top Crop       │")
        print("├──────────┼─────────────────────────┼──────────────┼──────────┼───────────┼───────────────┼────────────────┤")

        for w in weekly_summaries:
            window_str = f"{w['start_date'][5:]} to {w['end_date'][5:]}"
            top_crop = list(w["by_crop"].keys())[0] if w["by_crop"] else "N/A"
            print(
                f"│ {w['week_key']:<8} │ {window_str:<23} │ {w['total_weight_kg']:>10.2f}kg │ "
                f"{w['total_items_count']:>8} │ ${w['total_value']:>8.2f} │ {w['trend_symbol']:<13} │ {top_crop[:14]:<14} │"
            )

        print("└──────────┴─────────────────────────┴──────────────┴──────────┴───────────┴───────────────┴────────────────┘")

        # Visual ASCII Bar Chart for Weekly Production
        print(f"\n{TerminalColors.BOLD}📊 Visual Weekly Harvest Yield Bar Chart (kg):{TerminalColors.RESET}")
        max_kg = max((w["total_weight_kg"] for w in weekly_summaries), default=1.0)
        chart_width = 40

        for w in weekly_summaries:
            bar_len = int((w["total_weight_kg"] / max(1.0, max_kg)) * chart_width)
            bar_str = "█" * bar_len
            color = "green" if "📈" in w["trend_symbol"] else "cyan"
            print(f"  {w['week_key']} │ {colorize(bar_str, color)} {w['total_weight_kg']:.1f} kg")

    def display_executive_summary(self) -> None:
        """Renders executive KPI cards, status indicators, and rankings."""
        summary = AnalyticsEngine.generate_executive_summary(self.records)
        tot_kg = summary['total_weight_kg']
        tot_val = summary['total_estimated_value']

        print(f"\n{TerminalColors.BOLD}════════════════════ EXECUTIVE SUMMARY DASHBOARD ════════════════════{TerminalColors.RESET}")
        print(f"  {colorize('Total Harvest Entries:', 'bold')}   {summary['total_records']} logged events")
        print(f"  {colorize('Cumulative Harvest Weight:', 'bold')} {colorize(f'{tot_kg} kg', 'bright_green')}")
        print(f"  {colorize('Discrete Harvest Count:', 'bold')}   {summary['total_count_items']} pcs/bunches")
        print(f"  {colorize('Total Market Valuation:', 'bold')}    {colorize(f'${tot_val:.2f}', 'bright_cyan')}")
        print(f"  {colorize('Average Yield per Entry:', 'bold')}   {summary['average_harvest_kg']} kg")
        print(f"  {colorize('Average Weekly Output:', 'bold')}     {summary['average_weekly_kg']} kg/week (Target: {summary['weekly_target_kg']} kg)")
        print(f"  {colorize('Observation Timeline:', 'bold')}      {summary['earliest_date']} to {summary['latest_date']} ({summary['span_days']} days)")

        print(f"\n{TerminalColors.BOLD}Operational Status Indicators:{TerminalColors.RESET}")
        print(f"  • Yield Production Health: {summary['status_indicators']['yield_health']}")
        print(f"  • Spoilage & Quality Risk: {summary['status_indicators']['spoilage_level']}")
        print(f"  • Season Momentum:         {summary['status_indicators']['season_momentum']}")

        print(f"\n{TerminalColors.BOLD}🏆 Top Performing Crops (by Weight):{TerminalColors.RESET}")
        for idx, tc in enumerate(summary["top_crops_weight"][:5], 1):
            print(f"   {idx}. {tc['crop']:<20} {tc['kg']:>6.2f} kg ({tc['pct']}%)")

        print(f"\n{TerminalColors.BOLD}🏡 Garden Bed Performance Distribution:{TerminalColors.RESET}")
        for idx, tb in enumerate(summary["top_beds"][:5], 1):
            print(f"   {idx}. {tb['bed']:<20} {tb['kg']:>6.2f} kg ({tb['pct']}%)")

    def display_threshold_warnings(self) -> None:
        """Displays automated console warning flags highlighting anomalies, spoilage, or overdue beds."""
        warnings = AnalyticsEngine.detect_threshold_warnings(self.records)
        print(f"\n{TerminalColors.BOLD}⚠️  --- THRESHOLD WARNING & ANOMALY AUDIT --- ⚠️{TerminalColors.RESET}")
        if not warnings:
            print(colorize("✅ All harvest metrics operating within normal baseline boundaries.", "bright_green"))
            return

        for idx, w in enumerate(warnings, 1):
            color = "red" if w["severity"] == "CRITICAL" else ("yellow" if w["severity"] == "HIGH" else "bright_yellow")
            tag = colorize(f"[{w['severity']}] {w['code']}", color)
            print(f" {idx}. {tag}: {w['message']}")

    def export_reports_interactive(self) -> None:
        """Exports reports to Markdown, text audit log, or CSV."""
        print(f"\n{TerminalColors.BOLD}📁 --- MULTI-FORMAT REPORT EXPORT WIZARD --- 📁{TerminalColors.RESET}")
        print("  [1] Generate Structured Markdown Report (.md)")
        print("  [2] Generate Plain-Text Transaction Audit Log (.txt)")
        print("  [3] Export Raw CSV Records (.csv)")
        print("  [4] Export All Formats")
        sub = input("Choose export format [1-4]: ").strip()

        export_dir = self.storage.data_dir.parent / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        if sub in ("1", "4"):
            md_path = export_dir / f"harvest_summary_report_{timestamp}.md"
            ReportExporter.export_markdown_report(self.records, str(md_path))
            print(colorize(f"✅ Markdown report generated: {md_path}", "bright_green"))

        if sub in ("2", "4"):
            txt_path = export_dir / f"harvest_audit_log_{timestamp}.txt"
            ReportExporter.export_audit_log(self.records, str(txt_path))
            print(colorize(f"✅ Audit log generated: {txt_path}", "bright_green"))

        if sub in ("3", "4"):
            csv_path = export_dir / f"harvest_records_export_{timestamp}.csv"
            self.storage.export_csv(self.records, str(csv_path))
            print(colorize(f"✅ CSV database exported: {csv_path}", "bright_green"))

    def bulk_import_interactive(self) -> None:
        """Handles legacy CSV dataset ingestion with row error validation logging."""
        print(f"\n{TerminalColors.BOLD}📥 --- BULK DATASET IMPORT (CSV) --- 📥{TerminalColors.RESET}")
        sample_path = self.storage.data_dir / "legacy_import_sample.csv"
        default_path = str(sample_path) if sample_path.exists() else ""
        prompt_hint = f" [{default_path}]" if default_path else ""
        path_input = input(f"Enter path to CSV file{prompt_hint}: ").strip()
        if not path_input and default_path:
            path_input = default_path

        result = BulkDatasetImporter.import_csv(path_input)
        print(f"\n{TerminalColors.BOLD}Ingestion Results for:{TerminalColors.RESET} {path_input}")
        print(f"  • Total Processed Rows: {result.total_rows}")
        print(f"  • Valid Records Ingested: {colorize(str(result.success_count), 'bright_green')}")
        print(f"  • Rows with Validation Errors: {colorize(str(result.error_count), 'red' if result.error_count else 'green')}")
        print(f"  • Success Rate: {result.success_rate}%")

        if result.row_errors:
            print(f"\n{colorize('Row-by-Row Error Log:', 'bright_yellow')}")
            for err in result.row_errors[:10]:
                print(f"   [Row {err['row_number']}] Field '{err['field']}': {err['error']}")
            if len(result.row_errors) > 10:
                print(f"   ... and {len(result.row_errors) - 10} more row errors.")

        if result.imported_records:
            commit = input("\nCommit valid records to persistent database? [Y/n]: ").strip().lower()
            if commit in ("", "y", "yes"):
                self.records.extend(result.imported_records)
                self.storage.save_records(self.records)
                print(colorize(f"✅ {len(result.imported_records)} records successfully added and saved!", "bright_green"))
            else:
                print("Import cancelled by user.")

    def launch_gui(self) -> None:
        """Launches the Tkinter Graphical User Interface."""
        try:
            from .gui import launch_gui_app
            print(colorize("🚀 Launching Desktop Graphical Interface (Tkinter)...", "bright_cyan"))
            launch_gui_app(self.storage)
        except Exception as e:
            print(colorize(f"❌ Failed to launch Tkinter GUI: {e}", "red"))
