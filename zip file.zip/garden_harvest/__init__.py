"""Garden Harvest Register package initialization."""

__version__ = "1.0.0"
__author__ = "Garden Harvest Register Team"
