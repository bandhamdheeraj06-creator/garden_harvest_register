"""Bulk CSV dataset importer with schema auto-detection and row-by-row validation logging."""

import csv
import re
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from .models import HarvestRecord, CropCategory, QualityGrade
from .validation import (
    validate_crop_name,
    validate_date,
    validate_category,
    validate_quantity,
    validate_unit,
    validate_bed_id,
    validate_quality_grade,
    validate_estimated_value,
    sanitize_text
)


class BulkImportResult:
    """Holds summary statistics and errors from a bulk CSV dataset ingestion."""
    def __init__(self):
        self.total_rows: int = 0
        self.imported_records: List[HarvestRecord] = []
        self.row_errors: List[Dict[str, Any]] = []

    @property
    def success_count(self) -> int:
        return len(self.imported_records)

    @property
    def error_count(self) -> int:
        return len(self.row_errors)

    @property
    def success_rate(self) -> float:
        return round((self.success_count / self.total_rows * 100.0), 1) if self.total_rows > 0 else 0.0


class BulkDatasetImporter:
    """Ingests legacy CSV files, handles diverse header aliases, and performs defensive field checks."""

    # Common field aliases encountered in legacy garden spreadsheets
    HEADER_ALIASES = {
        "crop_name": ["crop_name", "crop", "produce", "item", "plant", "name", "variety"],
        "harvest_date": ["harvest_date", "date", "harvested_on", "date_harvested", "day"],
        "category": ["category", "cat", "crop_category", "type", "group"],
        "quantity": ["quantity", "qty", "amount", "weight", "volume", "count"],
        "unit": ["unit", "uom", "measurement", "units"],
        "bed_id": ["bed_id", "bed", "plot", "location", "plot_id", "garden_bed", "zone"],
        "quality_grade": ["quality_grade", "grade", "quality", "rating", "condition"],
        "estimated_value": ["estimated_value", "value", "price", "est_value", "worth", "market_value"],
        "notes": ["notes", "note", "comments", "remarks", "weather", "observations"]
    }

    @classmethod
    def map_headers(cls, headers: List[str]) -> Dict[str, str]:
        """Maps CSV file header names to canonical model field names."""
        mapping: Dict[str, str] = {}
        cleaned_headers = [h.strip().lower() for h in headers]

        for canonical, aliases in cls.HEADER_ALIASES.items():
            for idx, raw_header in enumerate(cleaned_headers):
                normalized = re.sub(r"[_\s\-]+", "_", raw_header)
                if normalized in aliases or any(alias in normalized for alias in aliases):
                    mapping[canonical] = headers[idx]
                    break
        return mapping

    @classmethod
    def import_csv(cls, filepath: str) -> BulkImportResult:
        """Reads a CSV file, parses each row through strict defensive validators,
        and produces validated records alongside detailed error logs.
        """
        path = Path(filepath)
        result = BulkImportResult()

        if not path.exists():
            result.row_errors.append({
                "row_number": 0,
                "field": "file",
                "error": f"Import file not found: {filepath}",
                "raw_data": {}
            })
            return result

        try:
            with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
                reader = csv.reader(f)
                try:
                    headers = next(reader)
                except StopIteration:
                    result.row_errors.append({
                        "row_number": 0,
                        "field": "header",
                        "error": "CSV file is empty.",
                        "raw_data": {}
                    })
                    return result

                col_map = cls.map_headers(headers)

                # Ensure minimum mandatory fields exist
                if "crop_name" not in col_map or "quantity" not in col_map:
                    result.row_errors.append({
                        "row_number": 1,
                        "field": "headers",
                        "error": (
                            f"Missing required columns in CSV header. Must have at least crop name and quantity. "
                            f"Detected headers: {headers}"
                        ),
                        "raw_data": {}
                    })
                    return result

                header_index = {h: idx for idx, h in enumerate(headers)}

                def get_val(row: list, canonical_field: str, default: str = "") -> str:
                    header_name = col_map.get(canonical_field)
                    if header_name and header_name in header_index:
                        idx = header_index[header_name]
                        if idx < len(row):
                            return row[idx].strip()
                    return default

                for row_idx, row in enumerate(reader, start=2):
                    # Skip empty rows
                    if not row or not any(field.strip() for field in row):
                        continue

                    result.total_rows += 1
                    errors: List[str] = []

                    # 1. Crop Name
                    raw_crop = get_val(row, "crop_name")
                    ok_crop, v_crop, err_crop = validate_crop_name(raw_crop)
                    if not ok_crop:
                        errors.append(f"Crop Name: {err_crop}")

                    # 2. Harvest Date
                    raw_date = get_val(row, "harvest_date")
                    if not raw_date:
                        # Fallback default if legacy date missing
                        raw_date = datetime.now().strftime("%Y-%m-%d")
                    ok_date, v_date, err_date = validate_date(raw_date, max_future_days=30)
                    if not ok_date:
                        errors.append(f"Harvest Date: {err_date}")

                    # 3. Category
                    raw_cat = get_val(row, "category", default=CropCategory.OTHER.value)
                    ok_cat, v_cat, err_cat = validate_category(raw_cat)
                    if not ok_cat:
                        v_cat = CropCategory.OTHER.value

                    # 4. Quantity
                    raw_qty = get_val(row, "quantity")
                    ok_qty, v_qty, err_qty = validate_quantity(raw_qty)
                    if not ok_qty:
                        errors.append(f"Quantity: {err_qty}")

                    # 5. Unit
                    raw_unit = get_val(row, "unit", default="kg")
                    ok_unit, v_unit, err_unit = validate_unit(raw_unit)
                    if not ok_unit:
                        errors.append(f"Unit: {err_unit}")

                    # 6. Bed / Plot ID
                    raw_bed = get_val(row, "bed_id", default="General")
                    ok_bed, v_bed, err_bed = validate_bed_id(raw_bed)
                    if not ok_bed:
                        errors.append(f"Bed ID: {err_bed}")

                    # 7. Quality Grade
                    raw_grade = get_val(row, "quality_grade", default=QualityGrade.GRADE_A.value)
                    ok_grade, v_grade, _ = validate_quality_grade(raw_grade)
                    if not ok_grade:
                        v_grade = QualityGrade.GRADE_A.value

                    # 8. Estimated Value
                    raw_val = get_val(row, "estimated_value", default="0.0")
                    ok_val, v_val, err_val = validate_estimated_value(raw_val)
                    if not ok_val:
                        v_val = 0.0

                    # 9. Notes
                    raw_notes = sanitize_text(get_val(row, "notes", default=""))

                    # If row has any fatal errors, record in error log
                    if errors:
                        result.row_errors.append({
                            "row_number": row_idx,
                            "field": "multiple" if len(errors) > 1 else errors[0].split(":")[0],
                            "error": "; ".join(errors),
                            "raw_data": {h: (row[i] if i < len(row) else "") for h, i in header_index.items()}
                        })
                    else:
                        rec = HarvestRecord(
                            crop_name=v_crop,
                            category=v_cat,
                            quantity=v_qty,
                            unit=v_unit,
                            harvest_date=v_date,
                            bed_id=v_bed,
                            quality_grade=v_grade,
                            estimated_value=v_val,
                            notes=raw_notes
                        )
                        result.imported_records.append(rec)

        except Exception as ex:
            result.row_errors.append({
                "row_number": 0,
                "field": "file_read",
                "error": f"Failed while processing CSV: {ex}",
                "raw_data": {}
            })

        return result
