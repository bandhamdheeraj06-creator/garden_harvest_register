"""Defensive input validation and sanitization module."""

import re
from datetime import datetime, date, timedelta
from typing import Tuple, Optional, Any, Callable
from .models import CropCategory, QualityGrade, HarvestUnit


class ValidationError(Exception):
    """Raised when user input fails domain validation."""
    pass


def sanitize_text(text: str, max_length: int = 200) -> str:
    """Removes harmful control characters, trims whitespace and caps length."""
    if text is None:
        return ""
    # Strip non-printable / control chars except regular whitespace
    cleaned = re.sub(r"[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F]", "", str(text))
    return cleaned.strip()[:max_length]


def validate_crop_name(name: str) -> Tuple[bool, str, str]:
    """Validates crop name string.
    Returns: (is_valid, cleaned_value, error_message)
    """
    cleaned = sanitize_text(name, max_length=60)
    if not cleaned:
        return False, "", "Crop name cannot be empty."
    if len(cleaned) < 2:
        return False, cleaned, "Crop name must be at least 2 characters long."
    # Allow letters, digits, spaces, hyphens, periods, parentheses, apostrophes
    if not re.match(r"^[\w\s\-\.\(\)\']+$", cleaned, re.UNICODE):
        return False, cleaned, "Crop name contains invalid characters. Use letters, numbers, spaces, and hyphens."
    return True, cleaned.title(), ""


def validate_date(date_str: str, max_future_days: int = 14) -> Tuple[bool, str, str]:
    """Validates harvest date string (YYYY-MM-DD format).
    Checks valid calendar date, leap years, non-future bound.
    Returns: (is_valid, cleaned_value, error_message)
    """
    cleaned = sanitize_text(date_str, max_length=15)
    if not cleaned:
        return False, "", "Harvest date cannot be empty."
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", cleaned):
        return False, cleaned, "Invalid date format. Expected YYYY-MM-DD (e.g. 2026-08-15)."
    try:
        parsed = datetime.strptime(cleaned, "%Y-%m-%d").date()
    except ValueError as e:
        return False, cleaned, f"Invalid calendar date ({e})."

    if parsed.year < 2000:
        return False, cleaned, "Harvest date must be on or after year 2000."

    today = date.today()
    max_date = today + timedelta(days=max_future_days)
    if parsed > max_date:
        return False, cleaned, f"Harvest date cannot be more than {max_future_days} days in the future (Limit: {max_date.isoformat()})."

    return True, cleaned, ""


def validate_category(category_input: str) -> Tuple[bool, str, str]:
    """Validates and maps category to supported CropCategory."""
    cleaned = sanitize_text(category_input, max_length=50)
    if not cleaned:
        return False, "", "Category cannot be empty."
    valid_categories = CropCategory.list_values()
    # Direct match or case-insensitive match
    for val in valid_categories:
        if cleaned.lower() == val.lower():
            return True, val, ""

    # Try fuzzy / alias resolution
    resolved = CropCategory.from_str(cleaned)
    if resolved != CropCategory.OTHER or cleaned.lower() in ("other", "misc", "miscellaneous"):
        return True, resolved.value, ""

    allowed_str = ", ".join(valid_categories)
    return False, cleaned, f"Unknown category '{cleaned}'. Allowed options: {allowed_str}"


def validate_quantity(qty_input: Any, min_val: float = 0.001, max_val: float = 50000.0) -> Tuple[bool, float, str]:
    """Validates numeric harvest quantity."""
    if qty_input is None:
        return False, 0.0, "Quantity cannot be empty."
    cleaned = str(qty_input).strip()
    try:
        val = float(cleaned)
    except (ValueError, TypeError):
        return False, 0.0, f"Quantity must be a valid number, got '{cleaned}'."

    if val < min_val:
        return False, val, f"Quantity must be at least {min_val}."
    if val > max_val:
        return False, val, f"Quantity exceeds realistic single-harvest maximum of {max_val}."

    return True, round(val, 4), ""


def validate_unit(unit_input: str) -> Tuple[bool, str, str]:
    """Validates harvest measurement unit."""
    cleaned = sanitize_text(unit_input, max_length=20).lower()
    if not cleaned:
        return False, "", "Unit cannot be empty."
    valid_units = HarvestUnit.list_values()
    alias_map = {
        "kilogram": "kg", "kilograms": "kg", "kilos": "kg", "kilo": "kg",
        "gram": "g", "grams": "g",
        "pound": "lbs", "pounds": "lbs", "lb": "lbs",
        "ounce": "oz", "ounces": "oz",
        "pieces": "pcs", "piece": "pcs", "pc": "pcs", "count": "pcs",
        "bunch": "bunches", "bundle": "bunches", "bundles": "bunches"
    }
    if cleaned in valid_units:
        return True, cleaned, ""
    if cleaned in alias_map:
        return True, alias_map[cleaned], ""

    allowed_str = ", ".join(valid_units)
    return False, cleaned, f"Invalid unit '{cleaned}'. Allowed units: {allowed_str}"


def validate_bed_id(bed_input: str) -> Tuple[bool, str, str]:
    """Validates garden bed / plot identifier."""
    cleaned = sanitize_text(bed_input, max_length=40)
    if not cleaned:
        return False, "", "Garden bed / plot identifier cannot be empty."
    if len(cleaned) < 1:
        return False, cleaned, "Bed identifier is too short."
    if not re.match(r"^[\w\s\-\.\#]+$", cleaned):
        return False, cleaned, "Bed identifier can only contain alphanumeric characters, hyphens, and spaces."
    return True, cleaned, ""


def validate_quality_grade(grade_input: str) -> Tuple[bool, str, str]:
    """Validates harvest quality grade."""
    cleaned = sanitize_text(grade_input, max_length=40)
    if not cleaned:
        return True, QualityGrade.GRADE_A.value, ""  # Default
    valid_grades = QualityGrade.list_values()
    for g in valid_grades:
        if cleaned.lower() == g.lower():
            return True, g, ""
    # Try resolving via code or alias
    resolved = QualityGrade.from_str(cleaned)
    return True, resolved.value, ""


def validate_estimated_value(value_input: Any) -> Tuple[bool, float, str]:
    """Validates financial estimated value."""
    if value_input is None or str(value_input).strip() == "":
        return True, 0.0, ""
    cleaned = str(value_input).strip().lstrip("$€£₹")
    try:
        val = float(cleaned)
    except (ValueError, TypeError):
        return False, 0.0, f"Estimated value must be a positive number or zero, got '{value_input}'."
    if val < 0.0:
        return False, 0.0, "Estimated value cannot be negative."
    if val > 1000000.0:
        return False, val, "Estimated value exceeds limit of 1,000,000."
    return True, round(val, 2), ""


def prompt_validated(
    prompt_text: str,
    validator: Callable[[str], Tuple[bool, Any, str]],
    default: Optional[str] = None,
    color_fn: Optional[Callable[[str, str], str]] = None,
) -> Any:
    """Centralized input wrapper function that loops defensively until valid user input is provided."""
    hint = f" [{default}]" if default is not None else ""
    full_prompt = f"{prompt_text}{hint}: "
    while True:
        try:
            raw = input(full_prompt).strip()
        except (KeyboardInterrupt, EOFError):
            print("\nInput cancelled.")
            raise

        if not raw and default is not None:
            raw = str(default)

        is_valid, parsed_value, error_msg = validator(raw)
        if is_valid:
            return parsed_value

        err_formatted = f"  -> [Validation Error]: {error_msg}"
        if color_fn:
            print(color_fn(err_formatted, "red"))
        else:
            print(err_formatted)
