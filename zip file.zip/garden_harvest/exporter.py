"""Multi-format summary report and audit log exporter."""

import os
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any
from .models import HarvestRecord
from .analytics import AnalyticsEngine
from .business_logic import BusinessLogicEngine


class ReportExporter:
    """Generates structured Markdown reports, plain-text audit logs, and summary CSV files."""

    @classmethod
    def export_markdown_report(
        cls,
        records: List[HarvestRecord],
        output_path: Optional[str] = None,
        weekly_target_kg: float = 25.0
    ) -> str:
        """Exports a comprehensive executive harvest report in GitHub-flavored Markdown."""
        summary = AnalyticsEngine.generate_executive_summary(records, weekly_target_kg)
        warnings = AnalyticsEngine.detect_threshold_warnings(records, weekly_target_kg)
        bed_yields = BusinessLogicEngine.calculate_bed_yields(records)
        cat_breakdown = BusinessLogicEngine.calculate_category_breakdown(records)

        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = [
            "# 🌿 Garden Harvest Register - Executive Summary Report",
            f"**Generated:** {now_str} | **Project:** Everyday Innovators #67 | **Domain:** Food & Agriculture\n",
            "---",
            "## 1. Executive Performance Dashboard",
            "",
            "| Metric | Value | Domain Target / Status |",
            "| :--- | :--- | :--- |",
            f"| **Total Harvest Log Entries** | {summary['total_records']} records | Baseline Active |",
            f"| **Total Harvest Yield (Weight)** | **{summary['total_weight_kg']} kg** | Net Agricultural Production |",
            f"| **Total Harvest Count (Discrete)** | {summary['total_count_items']} pcs/bunches | Herbs & Bunched Greens |",
            f"| **Total Estimated Valuation** | **${summary['total_estimated_value']:.2f}** | Market Valuation |",
            f"| **Average Yield per Harvest** | {summary['average_harvest_kg']} kg | Operational Efficiency |",
            f"| **Average Weekly Production** | {summary['average_weekly_kg']} kg/week | Target: {weekly_target_kg} kg/week |",
            f"| **Active Recording Window** | {summary['earliest_date']} to {summary['latest_date']} ({summary['span_days']} days) | Active Span |",
            "",
            "### Operational Status Indicators",
            f"- **Yield Health**: {summary['status_indicators']['yield_health']}",
            f"- **Spoilage & Loss**: {summary['status_indicators']['spoilage_level']}",
            f"- **Production Velocity**: {summary['status_indicators']['season_momentum']}",
            "",
            "---",
            "## 2. Weekly Production & Chronological Trends",
            "",
            "| Week Key | Date Window | Total Yield (kg) | Units (pcs) | Est. Value ($) | Trend vs Prior Week | Top Crop |",
            "| :---: | :---: | :---: | :---: | :---: | :---: | :--- |"
        ]

        for w in summary["weekly_totals"]:
            top_crop = list(w["by_crop"].keys())[0] if w["by_crop"] else "N/A"
            lines.append(
                f"| `{w['week_key']}` | {w['start_date']} to {w['end_date']} | "
                f"**{w['total_weight_kg']:.2f} kg** | {w['total_items_count']} | "
                f"${w['total_value']:.2f} | {w['trend_symbol']} | {top_crop} |"
            )

        lines.extend([
            "",
            "---",
            "## 3. Crop & Category Aggregations",
            "",
            "### Crop Category Distribution",
            "| Category | Total Yield (kg) | Units (pcs) | Entries | Est. Value ($) | Crops Cultivated |",
            "| :--- | :---: | :---: | :---: | :---: | :---: |"
        ])

        for cat, cdata in cat_breakdown.items():
            lines.append(
                f"| **{cat}** | {cdata['total_kg']:.2f} kg | {cdata['total_count']} | "
                f"{cdata['entries']} | ${cdata['total_value']:.2f} | {cdata['distinct_crops']} varieties |"
            )

        lines.extend([
            "",
            "### Top 5 Performing Crops by Weight",
            "| Rank | Crop Variety | Total Yield (kg) | % of Total Weight |",
            "| :---: | :--- | :---: | :---: |"
        ])
        for idx, tc in enumerate(summary["top_crops_weight"], 1):
            lines.append(f"| {idx} | **{tc['crop']}** | {tc['kg']} kg | {tc['pct']}% |")

        lines.extend([
            "",
            "---",
            "## 4. Garden Bed & Plot Efficiency",
            "",
            "| Bed / Plot Identifier | Total Weight (kg) | Harvest Events | Spoilage Rate | Est. Value ($) |",
            "| :--- | :---: | :---: | :---: | :---: |"
        ])
        for bed, bdata in bed_yields.items():
            lines.append(
                f"| `{bed}` | {bdata['total_kg']:.2f} kg | {bdata['entries']} | "
                f"{bdata['spoilage_rate_pct']}% | ${bdata['total_value']:.2f} |"
            )

        lines.extend([
            "",
            "---",
            "## 5. Threshold Warning Indicators & Audit Alerts",
            ""
        ])

        if warnings:
            for w in warnings:
                lines.append(f"- **[{w['severity']}] {w['code']}**: {w['message']}")
        else:
            lines.append("✅ No critical limit breaches, yield anomalies, or overdue plot alerts detected.")

        lines.extend([
            "",
            "---",
            "## 6. Harvest Quality Inspection Distribution",
            ""
        ])
        for q_name, q_info in summary["quality_distribution"].items():
            lines.append(f"- **{q_name}**: {q_info['count']} entries ({q_info['pct']}%)")

        content = "\n".join(lines) + "\n"

        if output_path:
            p = Path(output_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write(content)

        return content

    @classmethod
    def export_audit_log(
        cls,
        records: List[HarvestRecord],
        output_path: Optional[str] = None
    ) -> str:
        """Generates a plain-text cryptographic audit log with entry-level line items."""
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = [
            "=" * 78,
            "GARDEN HARVEST REGISTER - SECURE TRANSACTION AUDIT LOG",
            f"Generated: {now_str} | Standard Format: Plain-Text Audit Trail",
            "=" * 78,
            f"Total Records Audited: {len(records)}",
            "-" * 78,
            f"{'RECORD ID':<12} | {'DATE':<10} | {'CROP NAME':<18} | {'QTY & UNIT':<12} | {'BED ID':<10} | {'GRADE':<12}",
            "-" * 78,
        ]

        total_kg = 0.0
        total_val = 0.0
        for r in sorted(records, key=lambda x: x.harvest_date):
            qty_str = f"{r.quantity:g} {r.unit}"
            lines.append(
                f"{r.id:<12} | {r.harvest_date:<10} | {r.crop_name[:18]:<18} | "
                f"{qty_str:<12} | {r.bed_id[:10]:<10} | {r.quality_grade[:12]:<12}"
            )
            if r.is_weight_unit:
                total_kg += r.normalized_kg
            total_val += r.estimated_value

        lines.extend([
            "=" * 78,
            f"AUDIT TOTALS: Normalized Net Weight = {total_kg:.2f} kg | Total Valuation = ${total_val:.2f}",
            "INTEGRITY STATUS: VERIFIED - LOCAL STORAGE SYNCHRONIZED",
            "=" * 78,
        ])

        content = "\n".join(lines) + "\n"

        if output_path:
            p = Path(output_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write(content)

        return content
