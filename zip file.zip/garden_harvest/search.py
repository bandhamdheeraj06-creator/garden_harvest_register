"""Record query and search engine: keyword, category, and multi-parameter filtering."""

from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime
from .models import HarvestRecord, CropCategory, QualityGrade


class QueryEngine:
    """Performs dynamic filtering and retrieval over harvest records."""

    @staticmethod
    def filter_records(
        records: List[HarvestRecord],
        keyword: Optional[str] = None,
        category: Optional[str] = None,
        bed_id: Optional[str] = None,
        quality_grade: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        week_key: Optional[str] = None,
        min_kg: Optional[float] = None,
        max_kg: Optional[float] = None,
        sort_by: str = "date",
        reverse: bool = True,
    ) -> List[HarvestRecord]:
        """Filters records matching all provided criteria with sorting options."""
        filtered = list(records)

        # Keyword filter (crop name, bed, notes)
        if keyword:
            kw = keyword.strip().lower()
            filtered = [
                r for r in filtered
                if (kw in r.crop_name.lower() or
                    kw in r.bed_id.lower() or
                    kw in r.notes.lower() or
                    kw in r.category.lower() or
                    kw in r.id.lower())
            ]

        # Category filter
        if category:
            cat_norm = category.strip().lower()
            filtered = [r for r in filtered if r.category.lower() == cat_norm]

        # Bed filter
        if bed_id:
            bed_norm = bed_id.strip().lower()
            filtered = [r for r in filtered if r.bed_id.lower() == bed_norm]

        # Quality grade filter
        if quality_grade:
            q_norm = quality_grade.strip().lower()
            filtered = [r for r in filtered if q_norm in r.quality_grade.lower()]

        # Week key filter
        if week_key:
            wk_norm = week_key.strip().upper()
            filtered = [r for r in filtered if r.week_key == wk_norm]

        # Date range filters (YYYY-MM-DD)
        if date_from:
            try:
                dt_from = datetime.strptime(date_from.strip(), "%Y-%m-%d").date()
                filtered = [r for r in filtered if r.parsed_date >= dt_from]
            except ValueError:
                pass

        if date_to:
            try:
                dt_to = datetime.strptime(date_to.strip(), "%Y-%m-%d").date()
                filtered = [r for r in filtered if r.parsed_date <= dt_to]
            except ValueError:
                pass

        # Normalized weight boundaries
        if min_kg is not None:
            filtered = [r for r in filtered if r.normalized_kg >= min_kg]

        if max_kg is not None:
            filtered = [r for r in filtered if r.normalized_kg <= max_kg]

        # Sorting
        sort_keys = {
            "date": lambda r: r.harvest_date,
            "crop": lambda r: r.crop_name.lower(),
            "quantity": lambda r: r.normalized_kg,
            "value": lambda r: r.estimated_value,
            "category": lambda r: r.category.lower(),
            "bed": lambda r: r.bed_id.lower(),
            "id": lambda r: r.id,
        }

        key_fn = sort_keys.get(sort_by.lower(), sort_keys["date"])
        filtered.sort(key=key_fn, reverse=reverse)

        return filtered

    @staticmethod
    def paginate(records: List[HarvestRecord], page: int = 1, page_size: int = 10) -> Tuple[List[HarvestRecord], int, int]:
        """Paginates records for terminal or UI display.
        Returns: (records_for_page, total_pages, total_record_count)
        """
        total_count = len(records)
        if total_count == 0:
            return [], 0, 0

        page_size = max(1, page_size)
        total_pages = (total_count + page_size - 1) // page_size
        current_page = max(1, min(page, total_pages))

        start_idx = (current_page - 1) * page_size
        end_idx = start_idx + page_size

        return records[start_idx:end_idx], total_pages, total_count
