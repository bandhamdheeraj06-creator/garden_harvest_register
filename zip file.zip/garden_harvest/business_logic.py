"""Core business logic engine: weekly totals, aggregations, unit conversions, and trend analysis."""

from datetime import datetime, date, timedelta
from typing import List, Dict, Any, Optional
from collections import defaultdict
from .models import HarvestRecord, CropCategory, QualityGrade, HarvestUnit


class BusinessLogicEngine:
    """Core computational algorithms specifically programmed to record harvested quantities and generate weekly totals."""

    @staticmethod
    def get_week_boundaries(iso_year: int, iso_week: int) -> Tuple_Date_Range:
        """Calculates Monday start and Sunday end date for an ISO year and week number."""
        # ISO week 1 is the week with the first Thursday of the year
        fourth_jan = date(iso_year, 1, 4)
        start_of_week1 = fourth_jan - timedelta(days=fourth_jan.isoweekday() - 1)
        target_monday = start_of_week1 + timedelta(weeks=iso_week - 1)
        target_sunday = target_monday + timedelta(days=6)
        return target_monday.isoformat(), target_sunday.isoformat()

    @classmethod
    def calculate_weekly_totals(cls, records: List[HarvestRecord]) -> List[Dict[str, Any]]:
        """Groups harvest records by calendar week, computes weekly sums, category breakdowns,
        and chronological growth rate trends.
        """
        if not records:
            return []

        # Group records by (iso_year, iso_week)
        grouped: Dict[tuple, List[HarvestRecord]] = defaultdict(list)
        for r in records:
            grouped[(r.iso_year, r.iso_week)].append(r)

        # Sort chronological
        sorted_week_keys = sorted(grouped.keys(), key=lambda k: (k[0], k[1]))

        weekly_summaries: List[Dict[str, Any]] = []
        prev_weight_kg: Optional[float] = None

        for year, week_num in sorted_week_keys:
            week_records = grouped[(year, week_num)]
            week_label = f"{year}-W{week_num:02d}"
            start_date, end_date = cls.get_week_boundaries(year, week_num)

            total_weight_kg = 0.0
            total_items_count = 0
            total_value = 0.0
            damaged_kg = 0.0
            category_totals: Dict[str, float] = defaultdict(float)
            crop_totals: Dict[str, float] = defaultdict(float)
            bed_totals: Dict[str, float] = defaultdict(float)

            for rec in week_records:
                norm_kg = rec.normalized_kg
                if rec.is_weight_unit:
                    total_weight_kg += norm_kg
                    category_totals[rec.category] += norm_kg
                    crop_totals[rec.crop_name] += norm_kg
                    bed_totals[rec.bed_id] += norm_kg
                    if rec.quality_grade == QualityGrade.DAMAGED.value:
                        damaged_kg += norm_kg
                else:
                    total_items_count += int(rec.quantity)
                    category_totals[rec.category] += norm_kg
                    crop_totals[rec.crop_name] += norm_kg
                    bed_totals[rec.bed_id] += norm_kg

                total_value += rec.estimated_value

            total_weight_kg = round(total_weight_kg, 2)
            total_value = round(total_value, 2)
            damaged_kg = round(damaged_kg, 2)

            # Trend calculation compared to preceding chronological week
            pct_change: Optional[float] = None
            trend_symbol = "🆕 New"
            if prev_weight_kg is not None:
                if prev_weight_kg > 0:
                    pct = ((total_weight_kg - prev_weight_kg) / prev_weight_kg) * 100.0
                    pct_change = round(pct, 1)
                    if pct_change >= 5.0:
                        trend_symbol = f"📈 +{pct_change}%"
                    elif pct_change <= -5.0:
                        trend_symbol = f"📉 {pct_change}%"
                    else:
                        trend_symbol = f"➖ {pct_change}%"
                else:
                    trend_symbol = "📈 +100%" if total_weight_kg > 0 else "➖ 0.0%"
            prev_weight_kg = total_weight_kg

            summary = {
                "week_key": week_label,
                "year": year,
                "week_number": week_num,
                "start_date": start_date,
                "end_date": end_date,
                "harvest_count": len(week_records),
                "total_weight_kg": total_weight_kg,
                "total_items_count": total_items_count,
                "total_value": total_value,
                "damaged_kg": damaged_kg,
                "spoilage_rate_pct": round((damaged_kg / total_weight_kg * 100.0), 1) if total_weight_kg > 0 else 0.0,
                "trend_symbol": trend_symbol,
                "pct_change": pct_change,
                "distinct_crops": len(crop_totals),
                "by_category": dict(sorted(category_totals.items(), key=lambda x: x[1], reverse=True)),
                "by_crop": dict(sorted(crop_totals.items(), key=lambda x: x[1], reverse=True)),
                "by_bed": dict(sorted(bed_totals.items(), key=lambda x: x[1], reverse=True)),
            }
            weekly_summaries.append(summary)

        return weekly_summaries

    @classmethod
    def calculate_category_breakdown(cls, records: List[HarvestRecord]) -> Dict[str, Dict[str, Any]]:
        """Calculates aggregated metrics across all crop categories."""
        cat_data: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            "total_kg": 0.0,
            "total_count": 0,
            "entries": 0,
            "total_value": 0.0,
            "crops": set()
        })

        for r in records:
            cd = cat_data[r.category]
            cd["entries"] += 1
            cd["total_value"] += r.estimated_value
            cd["crops"].add(r.crop_name)
            if r.is_weight_unit:
                cd["total_kg"] += r.normalized_kg
            else:
                cd["total_count"] += int(r.quantity)

        result: Dict[str, Dict[str, Any]] = {}
        for cat, val in cat_data.items():
            result[cat] = {
                "total_kg": round(val["total_kg"], 2),
                "total_count": val["total_count"],
                "entries": val["entries"],
                "total_value": round(val["total_value"], 2),
                "distinct_crops": len(val["crops"]),
            }
        return dict(sorted(result.items(), key=lambda x: x[1]["total_kg"], reverse=True))

    @classmethod
    def calculate_bed_yields(cls, records: List[HarvestRecord]) -> Dict[str, Dict[str, Any]]:
        """Computes yield and efficiency metrics across different garden beds and plots."""
        bed_data: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            "total_kg": 0.0,
            "entries": 0,
            "total_value": 0.0,
            "damaged_kg": 0.0,
            "crops": set()
        })

        for r in records:
            bd = bed_data[r.bed_id]
            bd["entries"] += 1
            bd["total_value"] += r.estimated_value
            bd["crops"].add(r.crop_name)
            if r.is_weight_unit:
                bd["total_kg"] += r.normalized_kg
                if r.quality_grade == QualityGrade.DAMAGED.value:
                    bd["damaged_kg"] += r.normalized_kg

        result = {}
        for bed, val in bed_data.items():
            tot_kg = round(val["total_kg"], 2)
            dmg_kg = round(val["damaged_kg"], 2)
            spoil_rate = round((dmg_kg / tot_kg * 100.0), 1) if tot_kg > 0 else 0.0
            result[bed] = {
                "total_kg": tot_kg,
                "entries": val["entries"],
                "total_value": round(val["total_value"], 2),
                "damaged_kg": dmg_kg,
                "spoilage_rate_pct": spoil_rate,
                "distinct_crops": len(val["crops"]),
            }
        return dict(sorted(result.items(), key=lambda x: x[1]["total_kg"], reverse=True))


# Helper type annotation
Tuple_Date_Range = tuple[str, str]
