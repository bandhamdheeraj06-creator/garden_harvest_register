"""Lightweight Graphical User Interface (Tkinter) for Garden Harvest Register."""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import date, datetime
from typing import Optional, List
from .models import HarvestRecord, CropCategory, QualityGrade, HarvestUnit
from .validation import (
    validate_crop_name,
    validate_date,
    validate_category,
    validate_quantity,
    validate_unit,
    validate_bed_id,
    validate_quality_grade,
    validate_estimated_value,
    sanitize_text,
)
from .persistence import StorageManager
from .business_logic import BusinessLogicEngine
from .search import QueryEngine
from .analytics import AnalyticsEngine
from .exporter import ReportExporter
from .bulk_importer import BulkDatasetImporter


class HarvestAppGUI(tk.Tk):
    """Main Tkinter desktop application window for Garden Harvest Register."""

    def __init__(self, storage_manager: Optional[StorageManager] = None):
        super().__init__()
        self.title("🌿 Garden Harvest Register - Everyday Innovators #67")
        self.geometry("1060x700")
        self.minsize(880, 560)

        self.storage = storage_manager or StorageManager()
        self.records: List[HarvestRecord] = []

        self._configure_styles()
        self._create_widgets()
        self.reload_data()

    def _configure_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure("Treeview", font=("Segoe UI", 9), rowheight=24)
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"), foreground="#1e5128")
        style.configure("SubHeader.TLabel", font=("Segoe UI", 10), foreground="#4e6e58")
        style.configure("CardTitle.TLabel", font=("Segoe UI", 10, "bold"), foreground="#2d3748")
        style.configure("CardVal.TLabel", font=("Segoe UI", 14, "bold"), foreground="#2b6cb0")
        style.configure("Action.TButton", font=("Segoe UI", 9, "bold"))

    def _create_widgets(self):
        # Header Banner Frame
        header_frame = ttk.Frame(self, padding=(15, 10))
        header_frame.pack(fill=tk.X)

        title_lbl = ttk.Label(header_frame, text="🌿 Garden Harvest Register", style="Header.TLabel")
        title_lbl.pack(anchor=tk.W)

        sub_lbl = ttk.Label(
            header_frame,
            text="Everyday Innovators Project #67 | Food & Agriculture - Smart Yield Logging & Weekly Analytics",
            style="SubHeader.TLabel"
        )
        sub_lbl.pack(anchor=tk.W)

        # Tab Notebook
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=15, pady=(5, 15))

        self.tab_records = ttk.Frame(self.notebook, padding=10)
        self.tab_weekly = ttk.Frame(self.notebook, padding=10)
        self.tab_dashboard = ttk.Frame(self.notebook, padding=10)
        self.tab_import = ttk.Frame(self.notebook, padding=10)

        self.notebook.add(self.tab_records, text=" 📋 Harvest Records ")
        self.notebook.add(self.tab_weekly, text=" 📈 Weekly Totals & Trends ")
        self.notebook.add(self.tab_dashboard, text=" 🌿 Executive Dashboard ")
        self.notebook.add(self.tab_import, text=" 📥 Bulk CSV Import ")

        self._build_records_tab()
        self._build_weekly_tab()
        self._build_dashboard_tab()
        self._build_import_tab()

    # -------------------------------------------------------------------------
    # TAB 1: HARVEST RECORDS
    # -------------------------------------------------------------------------

    def _build_records_tab(self):
        # Search & Filter Bar
        filter_box = ttk.LabelFrame(self.tab_records, text="Search & Filter", padding=8)
        filter_box.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(filter_box, text="Keyword:").pack(side=tk.LEFT, padx=(5, 2))
        self.entry_search = ttk.Entry(filter_box, width=18)
        self.entry_search.pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(filter_box, text="Category:").pack(side=tk.LEFT, padx=(5, 2))
        self.combo_cat = ttk.Combobox(filter_box, values=["All"] + CropCategory.list_values(), state="readonly", width=14)
        self.combo_cat.current(0)
        self.combo_cat.pack(side=tk.LEFT, padx=(0, 10))

        btn_search = ttk.Button(filter_box, text="🔍 Filter", command=self.apply_filter)
        btn_search.pack(side=tk.LEFT, padx=5)

        btn_reset = ttk.Button(filter_box, text="Reset", command=self.reset_filter)
        btn_reset.pack(side=tk.LEFT, padx=5)

        # Records Treeview
        columns = ("id", "date", "crop", "cat", "qty", "norm_kg", "bed", "grade", "value")
        self.tree_records = ttk.Treeview(self.tab_records, columns=columns, show="headings", selectmode="browse")

        self.tree_records.heading("id", text="Record ID")
        self.tree_records.heading("date", text="Date")
        self.tree_records.heading("crop", text="Crop Variety")
        self.tree_records.heading("cat", text="Category")
        self.tree_records.heading("qty", text="Quantity")
        self.tree_records.heading("norm_kg", text="Norm. kg")
        self.tree_records.heading("bed", text="Plot / Bed")
        self.tree_records.heading("grade", text="Quality Grade")
        self.tree_records.heading("value", text="Est. Value ($)")

        self.tree_records.column("id", width=95, anchor=tk.CENTER)
        self.tree_records.column("date", width=85, anchor=tk.CENTER)
        self.tree_records.column("crop", width=140, anchor=tk.W)
        self.tree_records.column("cat", width=100, anchor=tk.W)
        self.tree_records.column("qty", width=95, anchor=tk.CENTER)
        self.tree_records.column("norm_kg", width=75, anchor=tk.E)
        self.tree_records.column("bed", width=90, anchor=tk.CENTER)
        self.tree_records.column("grade", width=130, anchor=tk.W)
        self.tree_records.column("value", width=85, anchor=tk.E)

        scroll_y = ttk.Scrollbar(self.tab_records, orient=tk.VERTICAL, command=self.tree_records.yview)
        self.tree_records.configure(yscrollcommand=scroll_y.set)

        self.tree_records.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)

        # Bottom Action Bar
        action_bar = ttk.Frame(self.tab_records, padding=(0, 10, 0, 0))
        action_bar.pack(fill=tk.X)

        btn_add = ttk.Button(action_bar, text="➕ Record New Harvest", style="Action.TButton", command=self.open_add_dialog)
        btn_add.pack(side=tk.LEFT, padx=5)

        btn_refresh = ttk.Button(action_bar, text="🔄 Reload Storage", command=self.reload_data)
        btn_refresh.pack(side=tk.LEFT, padx=5)

        btn_export_md = ttk.Button(action_bar, text="📄 Export Markdown Report", command=self.export_markdown)
        btn_export_md.pack(side=tk.RIGHT, padx=5)

        btn_export_csv = ttk.Button(action_bar, text="💾 Export CSV", command=self.export_csv)
        btn_export_csv.pack(side=tk.RIGHT, padx=5)

    # -------------------------------------------------------------------------
    # TAB 2: WEEKLY TOTALS & TRENDS
    # -------------------------------------------------------------------------

    def _build_weekly_tab(self):
        lbl_info = ttk.Label(
            self.tab_weekly,
            text="Computational algorithms aggregating weekly production, chronological growth rate trends, and top crops.",
            font=("Segoe UI", 9, "italic")
        )
        lbl_info.pack(anchor=tk.W, pady=(0, 10))

        columns = ("week", "window", "total_kg", "units", "value", "trend", "top_crop", "spoilage")
        self.tree_weekly = ttk.Treeview(self.tab_weekly, columns=columns, show="headings", selectmode="browse")

        self.tree_weekly.heading("week", text="ISO Week")
        self.tree_weekly.heading("window", text="Date Window (Mon - Sun)")
        self.tree_weekly.heading("total_kg", text="Total Yield (kg)")
        self.tree_weekly.heading("units", text="Units (pcs)")
        self.tree_weekly.heading("value", text="Est. Value ($)")
        self.tree_weekly.heading("trend", text="Growth Trend")
        self.tree_weekly.heading("top_crop", text="Top Producer")
        self.tree_weekly.heading("spoilage", text="Spoilage %")

        self.tree_weekly.column("week", width=90, anchor=tk.CENTER)
        self.tree_weekly.column("window", width=180, anchor=tk.CENTER)
        self.tree_weekly.column("total_kg", width=110, anchor=tk.E)
        self.tree_weekly.column("units", width=80, anchor=tk.CENTER)
        self.tree_weekly.column("value", width=95, anchor=tk.E)
        self.tree_weekly.column("trend", width=110, anchor=tk.CENTER)
        self.tree_weekly.column("top_crop", width=140, anchor=tk.W)
        self.tree_weekly.column("spoilage", width=90, anchor=tk.CENTER)

        self.tree_weekly.pack(fill=tk.BOTH, expand=True)

    # -------------------------------------------------------------------------
    # TAB 3: EXECUTIVE DASHBOARD
    # -------------------------------------------------------------------------

    def _build_dashboard_tab(self):
        # Top KPI Card Frame
        cards_frame = ttk.Frame(self.tab_dashboard)
        cards_frame.pack(fill=tk.X, pady=(0, 15))

        self.card_total_kg = self._create_kpi_card(cards_frame, "Total Yield Weight", "0.0 kg")
        self.card_total_val = self._create_kpi_card(cards_frame, "Market Valuation", "$0.00")
        self.card_avg_wk = self._create_kpi_card(cards_frame, "Avg Weekly Output", "0.0 kg/wk")
        self.card_health = self._create_kpi_card(cards_frame, "Yield Health", "On Track")

        # Bottom Split (Left: Top Crops & Beds, Right: Warnings)
        split_frame = ttk.Frame(self.tab_dashboard)
        split_frame.pack(fill=tk.BOTH, expand=True)

        left_frame = ttk.LabelFrame(split_frame, text="Rankings & Plot Breakdown", padding=8)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        self.txt_rankings = tk.Text(left_frame, wrap=tk.WORD, font=("Segoe UI", 9), height=14)
        self.txt_rankings.pack(fill=tk.BOTH, expand=True)

        right_frame = ttk.LabelFrame(split_frame, text="Automated Threshold Warning Indicators", padding=8)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))

        self.txt_warnings = tk.Text(right_frame, wrap=tk.WORD, font=("Segoe UI", 9), height=14)
        self.txt_warnings.pack(fill=tk.BOTH, expand=True)

    def _create_kpi_card(self, parent: ttk.Frame, title: str, init_val: str) -> ttk.Label:
        box = ttk.Frame(parent, relief=tk.RIDGE, padding=10)
        box.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)

        lbl_t = ttk.Label(box, text=title, style="CardTitle.TLabel")
        lbl_t.pack(anchor=tk.CENTER)

        lbl_v = ttk.Label(box, text=init_val, style="CardVal.TLabel")
        lbl_v.pack(anchor=tk.CENTER, pady=(4, 0))
        return lbl_v

    # -------------------------------------------------------------------------
    # TAB 4: BULK IMPORT
    # -------------------------------------------------------------------------

    def _build_import_tab(self):
        top_frame = ttk.LabelFrame(self.tab_import, text="Import Legacy CSV Dataset", padding=10)
        top_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(
            top_frame,
            text="Select a legacy CSV file containing historical garden records. The importer performs automatic header mapping and row-by-row defensive validation."
        ).pack(anchor=tk.W, pady=(0, 8))

        row_picker = ttk.Frame(top_frame)
        row_picker.pack(fill=tk.X)

        self.entry_csv_path = ttk.Entry(row_picker)
        self.entry_csv_path.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))

        btn_browse = ttk.Button(row_picker, text="Browse...", command=self._browse_csv)
        btn_browse.pack(side=tk.LEFT, padx=4)

        btn_validate = ttk.Button(row_picker, text="Ingest & Validate", command=self._run_bulk_import)
        btn_validate.pack(side=tk.LEFT, padx=4)

        self.lbl_import_status = ttk.Label(self.tab_import, text="Awaiting CSV file selection.", font=("Segoe UI", 9, "italic"))
        self.lbl_import_status.pack(anchor=tk.W, pady=(5, 10))

        log_frame = ttk.LabelFrame(self.tab_import, text="Validation & Error Log Details", padding=8)
        log_frame.pack(fill=tk.BOTH, expand=True)

        self.txt_import_log = tk.Text(log_frame, wrap=tk.WORD, font=("Courier New", 9))
        self.txt_import_log.pack(fill=tk.BOTH, expand=True)

        btn_commit = ttk.Button(self.tab_import, text="Commit Valid Ingested Records to Database", command=self._commit_import)
        btn_commit.pack(pady=10)
        self.pending_import_records: List[HarvestRecord] = []

    def _browse_csv(self):
        selected = filedialog.askopenfilename(
            title="Select Harvest CSV File",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if selected:
            self.entry_csv_path.delete(0, tk.END)
            self.entry_csv_path.insert(0, selected)

    def _run_bulk_import(self):
        filepath = self.entry_csv_path.get().strip()
        if not filepath:
            messagebox.showwarning("File Required", "Please select or enter a valid CSV filepath.")
            return

        res = BulkDatasetImporter.import_csv(filepath)
        self.pending_import_records = res.imported_records

        self.lbl_import_status.config(
            text=f"Processed {res.total_rows} rows: {res.success_count} Valid Records, {res.error_count} Row Errors ({res.success_rate}% Success Rate)"
        )

        self.txt_import_log.delete("1.0", tk.END)
        log_lines = [
            f"BULK IMPORT INGESTION LOG - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"File: {filepath}",
            f"Rows Processed: {res.total_rows} | Valid: {res.success_count} | Errors: {res.error_count}",
            "-" * 70,
        ]

        if res.row_errors:
            for e in res.row_errors:
                log_lines.append(f"[Row {e['row_number']}] Error on '{e['field']}': {e['error']}")
        else:
            log_lines.append("✅ All rows conformed to domain specifications without any validation errors!")

        self.txt_import_log.insert(tk.END, "\n".join(log_lines))

    def _commit_import(self):
        if not self.pending_import_records:
            messagebox.showinfo("No Records", "No valid pending records available to commit.")
            return
        count = len(self.pending_import_records)
        self.records.extend(self.pending_import_records)
        self.storage.save_records(self.records)
        self.pending_import_records = []
        self.reload_data()
        messagebox.showinfo("Import Success", f"Successfully committed {count} records to database!")

    # -------------------------------------------------------------------------
    # DATA REFRESH & BINDINGS
    # -------------------------------------------------------------------------

    def reload_data(self):
        self.records, _ = self.storage.load_records()
        self.populate_records_tree(self.records)
        self.populate_weekly_tree()
        self.populate_dashboard()

    def populate_records_tree(self, record_list: List[HarvestRecord]):
        for row in self.tree_records.get_children():
            self.tree_records.delete(row)

        for r in record_list:
            qty_str = f"{r.quantity:g} {r.unit}"
            val_str = f"${r.estimated_value:.2f}"
            self.tree_records.insert(
                "",
                tk.END,
                values=(
                    r.id,
                    r.harvest_date,
                    r.crop_name,
                    r.category,
                    qty_str,
                    f"{r.normalized_kg:.2f}",
                    r.bed_id,
                    r.quality_grade,
                    val_str,
                )
            )

    def populate_weekly_tree(self):
        for row in self.tree_weekly.get_children():
            self.tree_weekly.delete(row)

        weekly_data = BusinessLogicEngine.calculate_weekly_totals(self.records)
        for w in weekly_data:
            window_str = f"{w['start_date']} to {w['end_date']}"
            top_crop = list(w["by_crop"].keys())[0] if w["by_crop"] else "N/A"
            self.tree_weekly.insert(
                "",
                tk.END,
                values=(
                    w["week_key"],
                    window_str,
                    f"{w['total_weight_kg']:.2f}",
                    w["total_items_count"],
                    f"${w['total_value']:.2f}",
                    w["trend_symbol"],
                    top_crop,
                    f"{w['spoilage_rate_pct']:.1f}%"
                )
            )

    def populate_dashboard(self):
        summary = AnalyticsEngine.generate_executive_summary(self.records)
        warnings = AnalyticsEngine.detect_threshold_warnings(self.records)

        self.card_total_kg.config(text=f"{summary['total_weight_kg']} kg")
        self.card_total_val.config(text=f"${summary['total_estimated_value']:.2f}")
        self.card_avg_wk.config(text=f"{summary['average_weekly_kg']} kg/wk")
        self.card_health.config(text=summary["status_indicators"]["yield_health"].split("(")[0].strip())

        # Populate rankings text
        rank_lines = [
            "🏆 TOP CROPS BY HARVEST WEIGHT:",
            "-" * 38
        ]
        for idx, tc in enumerate(summary["top_crops_weight"][:5], 1):
            rank_lines.append(f" {idx}. {tc['crop']:<18} {tc['kg']} kg ({tc['pct']}%)")

        rank_lines.extend([
            "",
            "🏡 GARDEN BED PRODUCTION YIELD:",
            "-" * 38
        ])
        for idx, tb in enumerate(summary["top_beds"][:5], 1):
            rank_lines.append(f" {idx}. {tb['bed']:<18} {tb['kg']} kg ({tb['pct']}%)")

        rank_lines.extend([
            "",
            "📊 HARVEST QUALITY DISTRIBUTION:",
            "-" * 38
        ])
        for q, qinfo in summary["quality_distribution"].items():
            rank_lines.append(f" • {q}: {qinfo['count']} records ({qinfo['pct']}%)")

        self.txt_rankings.delete("1.0", tk.END)
        self.txt_rankings.insert(tk.END, "\n".join(rank_lines))

        # Populate warnings text
        warn_lines = []
        if warnings:
            for w in warnings:
                warn_lines.append(f"[{w['severity']}] {w['code']}")
                warn_lines.append(f"  {w['message']}\n")
        else:
            warn_lines.append("✅ All garden harvest metrics conform to baseline thresholds.")

        self.txt_warnings.delete("1.0", tk.END)
        self.txt_warnings.insert(tk.END, "\n".join(warn_lines))

    def apply_filter(self):
        kw = self.entry_search.get().strip()
        cat = self.combo_cat.get().strip()
        category_arg = None if cat in ("", "All") else cat
        filtered = QueryEngine.filter_records(
            self.records,
            keyword=kw if kw else None,
            category=category_arg,
            sort_by="date",
            reverse=True
        )
        self.populate_records_tree(filtered)

    def reset_filter(self):
        self.entry_search.delete(0, tk.END)
        self.combo_cat.current(0)
        self.populate_records_tree(self.records)

    def export_markdown(self):
        export_path = filedialog.asksaveasfilename(
            defaultextension=".md",
            filetypes=[("Markdown files", "*.md")],
            initialfile=f"harvest_report_{datetime.now().strftime('%Y%m%d')}.md"
        )
        if export_path:
            ReportExporter.export_markdown_report(self.records, export_path)
            messagebox.showinfo("Export Successful", f"Markdown summary report saved to:\n{export_path}")

    def export_csv(self):
        export_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            initialfile=f"harvest_records_{datetime.now().strftime('%Y%m%d')}.csv"
        )
        if export_path:
            self.storage.export_csv(self.records, export_path)
            messagebox.showinfo("Export Successful", f"CSV dataset saved to:\n{export_path}")

    def open_add_dialog(self):
        AddHarvestDialog(self, self._on_record_added)

    def _on_record_added(self, new_record: HarvestRecord):
        self.records.append(new_record)
        self.storage.save_records(self.records)
        self.reload_data()
        messagebox.showinfo("Success", f"Recorded harvest for '{new_record.crop_name}' ({new_record.quantity} {new_record.unit})")


class AddHarvestDialog(tk.Toplevel):
    """Modal dialog with live defensive input validation for logging harvest entries."""

    def __init__(self, parent: HarvestAppGUI, callback):
        super().__init__(parent)
        self.callback = callback
        self.title("➕ Record New Harvest")
        self.geometry("480x520")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self._create_form()

    def _create_form(self):
        frame = ttk.Frame(self, padding=20)
        frame.pack(fill=tk.BOTH, expand=True)

        row = 0
        ttk.Label(frame, text="Crop Name:").grid(row=row, column=0, sticky=tk.W, pady=6)
        self.ent_crop = ttk.Entry(frame, width=28)
        self.ent_crop.grid(row=row, column=1, sticky=tk.W, pady=6)

        row += 1
        ttk.Label(frame, text="Category:").grid(row=row, column=0, sticky=tk.W, pady=6)
        self.cb_cat = ttk.Combobox(frame, values=CropCategory.list_values(), state="readonly", width=26)
        self.cb_cat.current(0)
        self.cb_cat.grid(row=row, column=1, sticky=tk.W, pady=6)

        row += 1
        ttk.Label(frame, text="Harvest Date:").grid(row=row, column=0, sticky=tk.W, pady=6)
        self.ent_date = ttk.Entry(frame, width=28)
        self.ent_date.insert(0, date.today().isoformat())
        self.ent_date.grid(row=row, column=1, sticky=tk.W, pady=6)

        row += 1
        ttk.Label(frame, text="Quantity:").grid(row=row, column=0, sticky=tk.W, pady=6)
        self.ent_qty = ttk.Entry(frame, width=28)
        self.ent_qty.grid(row=row, column=1, sticky=tk.W, pady=6)

        row += 1
        ttk.Label(frame, text="Unit:").grid(row=row, column=0, sticky=tk.W, pady=6)
        self.cb_unit = ttk.Combobox(frame, values=HarvestUnit.list_values(), state="readonly", width=26)
        self.cb_unit.current(0)
        self.cb_unit.grid(row=row, column=1, sticky=tk.W, pady=6)

        row += 1
        ttk.Label(frame, text="Plot / Bed ID:").grid(row=row, column=0, sticky=tk.W, pady=6)
        self.ent_bed = ttk.Entry(frame, width=28)
        self.ent_bed.insert(0, "Bed-1")
        self.ent_bed.grid(row=row, column=1, sticky=tk.W, pady=6)

        row += 1
        ttk.Label(frame, text="Quality Grade:").grid(row=row, column=0, sticky=tk.W, pady=6)
        self.cb_grade = ttk.Combobox(frame, values=QualityGrade.list_values(), state="readonly", width=26)
        self.cb_grade.current(0)
        self.cb_grade.grid(row=row, column=1, sticky=tk.W, pady=6)

        row += 1
        ttk.Label(frame, text="Est. Value ($):").grid(row=row, column=0, sticky=tk.W, pady=6)
        self.ent_val = ttk.Entry(frame, width=28)
        self.ent_val.insert(0, "0.0")
        self.ent_val.grid(row=row, column=1, sticky=tk.W, pady=6)

        row += 1
        ttk.Label(frame, text="Notes:").grid(row=row, column=0, sticky=tk.W, pady=6)
        self.ent_notes = ttk.Entry(frame, width=28)
        self.ent_notes.grid(row=row, column=1, sticky=tk.W, pady=6)

        row += 1
        self.lbl_error = ttk.Label(frame, text="", foreground="red", wraplength=400)
        self.lbl_error.grid(row=row, column=0, columnspan=2, pady=10)

        row += 1
        btn_box = ttk.Frame(frame)
        btn_box.grid(row=row, column=0, columnspan=2, pady=10)

        btn_save = ttk.Button(btn_box, text="Save Entry", command=self._submit)
        btn_save.pack(side=tk.LEFT, padx=6)

        btn_cancel = ttk.Button(btn_box, text="Cancel", command=self.destroy)
        btn_cancel.pack(side=tk.LEFT, padx=6)

    def _submit(self):
        # Validate all fields defensively
        crop_raw = self.ent_crop.get()
        ok_crop, v_crop, err_crop = validate_crop_name(crop_raw)
        if not ok_crop:
            self.lbl_error.config(text=err_crop)
            return

        date_raw = self.ent_date.get()
        ok_date, v_date, err_date = validate_date(date_raw)
        if not ok_date:
            self.lbl_error.config(text=err_date)
            return

        qty_raw = self.ent_qty.get()
        ok_qty, v_qty, err_qty = validate_quantity(qty_raw)
        if not ok_qty:
            self.lbl_error.config(text=err_qty)
            return

        bed_raw = self.ent_bed.get()
        ok_bed, v_bed, err_bed = validate_bed_id(bed_raw)
        if not ok_bed:
            self.lbl_error.config(text=err_bed)
            return

        val_raw = self.ent_val.get()
        ok_val, v_val, err_val = validate_estimated_value(val_raw)
        if not ok_val:
            self.lbl_error.config(text=err_val)
            return

        rec = HarvestRecord(
            crop_name=v_crop,
            category=self.cb_cat.get(),
            quantity=v_qty,
            unit=self.cb_unit.get(),
            harvest_date=v_date,
            bed_id=v_bed,
            quality_grade=self.cb_grade.get(),
            estimated_value=v_val,
            notes=sanitize_text(self.ent_notes.get())
        )

        self.callback(rec)
        self.destroy()


def launch_gui_app(storage_manager: Optional[StorageManager] = None):
    """Entry point function to launch the desktop Tkinter application."""
    app = HarvestAppGUI(storage_manager)
    app.mainloop()
