"""Executive summary generation, status indicators, and threshold warning engine."""

import math
from datetime import datetime, date, timedelta
from typing import List, Dict, Any, Tuple
from collections import defaultdict
from .models import HarvestRecord, QualityGrade
from .business_logic import BusinessLogicEngine


class AnalyticsEngine:
    """Computes executive KPIs, status indicators, statistical distributions, and threshold warnings."""

    @classmethod
    def generate_executive_summary(
        cls,
        records: List[HarvestRecord],
        weekly_target_kg: float = 25.0
    ) -> Dict[str, Any]:
        """Calculates comprehensive executive summary metrics and status indicators."""
        if not records:
            return {
                "total_records": 0,
                "total_weight_kg": 0.0,
                "total_count_items": 0,
                "total_estimated_value": 0.0,
                "average_harvest_kg": 0.0,
                "average_weekly_kg": 0.0,
                "earliest_date": "N/A",
                "latest_date": "N/A",
                "span_days": 0,
                "status_indicators": {
                    "yield_health": "⚪ No Data",
                    "spoilage_level": "⚪ No Data",
                    "season_momentum": "⚪ No Data",
                },
                "quality_distribution": {},
                "top_crops_weight": [],
                "top_crops_value": [],
                "top_beds": [],
                "weekly_totals": [],
            }

        total_records = len(records)
        total_weight_kg = 0.0
        total_count_items = 0
        total_value = 0.0
        damaged_kg = 0.0

        crop_weights: Dict[str, float] = defaultdict(float)
        crop_values: Dict[str, float] = defaultdict(float)
        bed_weights: Dict[str, float] = defaultdict(float)
        quality_counts: Dict[str, int] = defaultdict(int)

        dates: List[date] = []

        for r in records:
            dates.append(r.parsed_date)
            quality_counts[r.quality_grade] += 1
            total_value += r.estimated_value
            crop_values[r.crop_name] += r.estimated_value

            if r.is_weight_unit:
                total_weight_kg += r.normalized_kg
                crop_weights[r.crop_name] += r.normalized_kg
                bed_weights[r.bed_id] += r.normalized_kg
                if r.quality_grade == QualityGrade.DAMAGED.value:
                    damaged_kg += r.normalized_kg
            else:
                total_count_items += int(r.quantity)
                crop_weights[r.crop_name] += r.normalized_kg
                bed_weights[r.bed_id] += r.normalized_kg

        dates.sort()
        earliest_date = dates[0].isoformat()
        latest_date = dates[-1].isoformat()
        span_days = max(1, (dates[-1] - dates[0]).days + 1)

        # Weekly totals & trend
        weekly_totals = BusinessLogicEngine.calculate_weekly_totals(records)
        active_weeks = max(1, len(weekly_totals))

        avg_harvest_kg = round(total_weight_kg / total_records, 2)
        avg_weekly_kg = round(total_weight_kg / active_weeks, 2)

        # Status Indicators
        # 1. Yield Health
        if avg_weekly_kg >= weekly_target_kg * 1.1:
            yield_health = f"🟢 Target Exceeded ({avg_weekly_kg} kg/wk vs {weekly_target_kg} kg goal)"
        elif avg_weekly_kg >= weekly_target_kg * 0.8:
            yield_health = f"🟡 On Track ({avg_weekly_kg} kg/wk vs {weekly_target_kg} kg goal)"
        else:
            yield_health = f"🔴 Below Target ({avg_weekly_kg} kg/wk vs {weekly_target_kg} kg goal)"

        # 2. Spoilage Level
        spoilage_rate = (damaged_kg / total_weight_kg * 100.0) if total_weight_kg > 0 else 0.0
        if spoilage_rate <= 4.0:
            spoilage_level = f"🟢 Excellent (<4% damaged: {spoilage_rate:.1f}%)"
        elif spoilage_rate <= 10.0:
            spoilage_level = f"🟡 Moderate Warning ({spoilage_rate:.1f}% damaged)"
        else:
            spoilage_level = f"🔴 Critical Spoilage Alert ({spoilage_rate:.1f}% damaged)"

        # 3. Season Momentum (based on recent week vs previous)
        if len(weekly_totals) >= 2:
            recent_pct = weekly_totals[-1].get("pct_change")
            if recent_pct is not None:
                if recent_pct >= 10.0:
                    momentum = f"🚀 Accelerating (+{recent_pct}% recent surge)"
                elif recent_pct <= -10.0:
                    momentum = f"📉 Slowing ({recent_pct}% drop)"
                else:
                    momentum = f"⚖️ Steady Production ({recent_pct:+0.1f}%)"
            else:
                momentum = "⚖️ Steady Harvest Flow"
        else:
            momentum = "🌱 Baseline Season Established"

        # Top rankings
        top_crops_weight = sorted(
            [{"crop": k, "kg": round(v, 2), "pct": round(v / total_weight_kg * 100.0, 1) if total_weight_kg > 0 else 0.0}
             for k, v in crop_weights.items()],
            key=lambda x: x["kg"],
            reverse=True
        )[:5]

        top_crops_value = sorted(
            [{"crop": k, "value": round(v, 2), "pct": round(v / total_value * 100.0, 1) if total_value > 0 else 0.0}
             for k, v in crop_values.items() if v > 0],
            key=lambda x: x["value"],
            reverse=True
        )[:5]

        top_beds = sorted(
            [{"bed": k, "kg": round(v, 2), "pct": round(v / total_weight_kg * 100.0, 1) if total_weight_kg > 0 else 0.0}
             for k, v in bed_weights.items()],
            key=lambda x: x["kg"],
            reverse=True
        )[:5]

        # Quality distribution with percentages
        quality_dist = {}
        for q_name, cnt in quality_counts.items():
            quality_dist[q_name] = {
                "count": cnt,
                "pct": round(cnt / total_records * 100.0, 1)
            }

        return {
            "total_records": total_records,
            "total_weight_kg": round(total_weight_kg, 2),
            "total_count_items": total_count_items,
            "total_estimated_value": round(total_value, 2),
            "average_harvest_kg": avg_harvest_kg,
            "average_weekly_kg": avg_weekly_kg,
            "weekly_target_kg": weekly_target_kg,
            "earliest_date": earliest_date,
            "latest_date": latest_date,
            "span_days": span_days,
            "active_weeks": active_weeks,
            "damaged_kg": round(damaged_kg, 2),
            "spoilage_rate_pct": round(spoilage_rate, 1),
            "status_indicators": {
                "yield_health": yield_health,
                "spoilage_level": spoilage_level,
                "season_momentum": momentum,
            },
            "quality_distribution": quality_dist,
            "top_crops_weight": top_crops_weight,
            "top_crops_value": top_crops_value,
            "top_beds": top_beds,
            "weekly_totals": weekly_totals,
        }

    @classmethod
    def detect_threshold_warnings(
        cls,
        records: List[HarvestRecord],
        target_weekly_kg: float = 25.0,
        reference_date: Optional[date] = None
    ) -> List[Dict[str, str]]:
        """Scans dataset for threshold breaches, statistical anomalies, and overdue plot activity."""
        warnings: List[Dict[str, str]] = []
        if not records:
            return warnings

        # 1. Statistical Outlier Detection (Z-Score on crop harvest weights)
        crop_entries: Dict[str, List[HarvestRecord]] = defaultdict(list)
        for r in records:
            if r.is_weight_unit:
                crop_entries[r.crop_name].append(r)

        for crop, c_records in crop_entries.items():
            if len(c_records) >= 3:
                weights = [r.normalized_kg for r in c_records]
                mean_w = sum(weights) / len(weights)
                variance = sum((w - mean_w) ** 2 for w in weights) / len(weights)
                std_dev = math.sqrt(variance)

                if std_dev > 0.05:
                    for r in c_records:
                        z_score = (r.normalized_kg - mean_w) / std_dev
                        if z_score >= 2.5 and r.normalized_kg > 5.0:
                            warnings.append({
                                "severity": "HIGH",
                                "code": "STAT_ANOMALY_SPIKE",
                                "message": (
                                    f"Yield spike anomaly: {r.crop_name} on {r.harvest_date} "
                                    f"({r.quantity} {r.unit} = {r.normalized_kg} kg) is {z_score:.1f}σ above "
                                    f"crop mean ({mean_w:.2f} kg). Verify entry accuracy."
                                )
                            })

        # 2. Spoilage Limit Breaches (any single damaged harvest > 3.0 kg or spoiled batch)
        for r in records:
            if r.quality_grade == QualityGrade.DAMAGED.value:
                if r.normalized_kg >= 2.5:
                    warnings.append({
                        "severity": "CRITICAL",
                        "code": "SPOILAGE_LOSS",
                        "message": (
                            f"Significant harvest spoilage loss in {r.bed_id}: {r.normalized_kg} kg "
                            f"of {r.crop_name} marked as Damaged on {r.harvest_date}. Notes: '{r.notes or 'None'}'"
                        )
                    })

        # 3. Weekly Target Deficit Alert
        weekly_totals = BusinessLogicEngine.calculate_weekly_totals(records)
        if weekly_totals:
            recent_week = weekly_totals[-1]
            if recent_week["total_weight_kg"] < target_weekly_kg * 0.5:
                warnings.append({
                    "severity": "MEDIUM",
                    "code": "WEEKLY_DEFICIT",
                    "message": (
                        f"Weekly target shortfall in {recent_week['week_key']}: recorded "
                        f"{recent_week['total_weight_kg']} kg, which is less than 50% of target "
                        f"({target_weekly_kg} kg)."
                    )
                })

        # 4. Inactive / Overdue Bed Monitoring
        ref = reference_date or max(r.parsed_date for r in records)
        bed_last_date: Dict[str, date] = {}
        for r in records:
            p_date = r.parsed_date
            if r.bed_id not in bed_last_date or p_date > bed_last_date[r.bed_id]:
                bed_last_date[r.bed_id] = p_date

        for bed, l_date in bed_last_date.items():
            inactive_days = (ref - l_date).days
            if inactive_days >= 21:
                warnings.append({
                    "severity": "MEDIUM",
                    "code": "OVERDUE_PLOT",
                    "message": (
                        f"Plot inactivity notice: {bed} has had no harvests recorded in the "
                        f"last {inactive_days} days (Last harvest: {l_date.isoformat()})."
                    )
                })

        return warnings
