"""Garden Harvest Register - Core Data Models and Operational Types."""

from dataclasses import dataclass, field, asdict
from datetime import datetime, date
from enum import Enum
from typing import Dict, Any, Optional
import uuid


class CropCategory(str, Enum):
    VEGETABLE = "Vegetable"
    FRUIT = "Fruit"
    HERB = "Herb"
    BERRY = "Berry"
    ROOT_TUBER = "Root & Tuber"
    LEAFY_GREEN = "Leafy Green"
    LEGUME = "Legume"
    OTHER = "Other"

    @classmethod
    def list_values(cls) -> list[str]:
        return [c.value for c in cls]

    @classmethod
    def from_str(cls, value: str) -> "CropCategory":
        normalized = value.strip().lower()
        mapping = {
            "vegetable": cls.VEGETABLE,
            "veg": cls.VEGETABLE,
            "fruit": cls.FRUIT,
            "herb": cls.HERB,
            "berry": cls.BERRY,
            "berries": cls.BERRY,
            "root & tuber": cls.ROOT_TUBER,
            "root": cls.ROOT_TUBER,
            "tuber": cls.ROOT_TUBER,
            "roots": cls.ROOT_TUBER,
            "leafy green": cls.LEAFY_GREEN,
            "greens": cls.LEAFY_GREEN,
            "leafy": cls.LEAFY_GREEN,
            "salad": cls.LEAFY_GREEN,
            "legume": cls.LEGUME,
            "legumes": cls.LEGUME,
            "beans": cls.LEGUME,
            "other": cls.OTHER,
        }
        if normalized in mapping:
            return mapping[normalized]
        for item in cls:
            if item.value.lower() == normalized:
                return item
        return cls.OTHER


class QualityGrade(str, Enum):
    GRADE_A = "Grade A (Premium)"
    GRADE_B = "Grade B (Standard)"
    GRADE_C = "Grade C (Processing)"
    DAMAGED = "Damaged / Spoiled"

    @classmethod
    def list_values(cls) -> list[str]:
        return [q.value for q in cls]

    @classmethod
    def from_str(cls, value: str) -> "QualityGrade":
        normalized = value.strip().upper()
        if "A" in normalized and "DAMAGE" not in normalized:
            return cls.GRADE_A
        if "B" in normalized:
            return cls.GRADE_B
        if "C" in normalized:
            return cls.GRADE_C
        if "DAMAG" in normalized or "SPOIL" in normalized:
            return cls.DAMAGED
        return cls.GRADE_B


class HarvestUnit(str, Enum):
    KG = "kg"
    G = "g"
    LBS = "lbs"
    OZ = "oz"
    PIECES = "pcs"
    BUNCHES = "bunches"

    @classmethod
    def list_values(cls) -> list[str]:
        return [u.value for u in cls]

    @classmethod
    def normalize_to_kg(cls, quantity: float, unit_str: str) -> float:
        """Converts harvest quantities to kilogram equivalents where applicable."""
        u = unit_str.strip().lower()
        if u == "kg":
            return round(quantity, 4)
        if u == "g":
            return round(quantity / 1000.0, 4)
        if u in ("lbs", "lb", "pound", "pounds"):
            return round(quantity * 0.45359237, 4)
        if u in ("oz", "ounce", "ounces"):
            return round(quantity * 0.0283495, 4)
        # Unit-based counts (pcs, bunches): retain quantity directly for discrete metrics
        return round(quantity, 4)


@dataclass
class HarvestRecord:
    """Represents a single harvest event record."""
    crop_name: str
    category: str
    quantity: float
    unit: str
    harvest_date: str  # YYYY-MM-DD
    bed_id: str
    quality_grade: str = QualityGrade.GRADE_A.value
    estimated_value: float = 0.0
    notes: str = ""
    id: str = field(default_factory=lambda: f"HRV-{uuid.uuid4().hex[:6].upper()}")
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def __post_init__(self):
        # Normalize fields
        self.crop_name = self.crop_name.strip()
        self.bed_id = self.bed_id.strip()
        self.notes = self.notes.strip()
        self.quantity = float(self.quantity)
        self.estimated_value = float(self.estimated_value)

    @property
    def normalized_kg(self) -> float:
        """Return the quantity normalized to kilograms if weight unit, or raw amount."""
        return HarvestUnit.normalize_to_kg(self.quantity, self.unit)

    @property
    def is_weight_unit(self) -> bool:
        return self.unit.lower() in ("kg", "g", "lbs", "oz")

    @property
    def parsed_date(self) -> date:
        return datetime.strptime(self.harvest_date, "%Y-%m-%d").date()

    @property
    def iso_year(self) -> int:
        return self.parsed_date.isocalendar()[0]

    @property
    def iso_week(self) -> int:
        return self.parsed_date.isocalendar()[1]

    @property
    def week_key(self) -> str:
        """Standard formatted week key, e.g. '2026-W42'."""
        cal = self.parsed_date.isocalendar()
        return f"{cal[0]}-W{cal[1]:02d}"

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["normalized_kg"] = self.normalized_kg
        data["week_key"] = self.week_key
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HarvestRecord":
        return cls(
            id=data.get("id", f"HRV-{uuid.uuid4().hex[:6].upper()}"),
            crop_name=data["crop_name"],
            category=data.get("category", CropCategory.OTHER.value),
            quantity=float(data["quantity"]),
            unit=data.get("unit", "kg"),
            harvest_date=data["harvest_date"],
            bed_id=data.get("bed_id", "General"),
            quality_grade=data.get("quality_grade", QualityGrade.GRADE_A.value),
            estimated_value=float(data.get("estimated_value", 0.0)),
            notes=data.get("notes", ""),
            created_at=data.get("created_at", datetime.now().isoformat()),
        )
