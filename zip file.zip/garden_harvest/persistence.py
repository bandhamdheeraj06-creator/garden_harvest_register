"""Local file persistence manager for structured JSON and CSV storage."""

import os
import json
import csv
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from .models import HarvestRecord, QualityGrade, CropCategory


class StorageError(Exception):
    """Raised when data serialization or deserialization fails."""
    pass


class StorageManager:
    """Handles persistent reading, writing, schema checks, and recovery for harvest records."""

    SCHEMA_VERSION = "1.0"

    def __init__(self, data_dir: Optional[str] = None):
        if data_dir:
            self.data_dir = Path(data_dir)
        else:
            # Default to project root / data directory
            self.data_dir = Path(__file__).resolve().parent.parent / "data"

        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "harvests.json"
        self.csv_path = self.data_dir / "harvests.csv"

    def load_records(self) -> Tuple[List[HarvestRecord], List[str]]:
        """Loads records from the local JSON storage file.
        Detects missing, unformatted, or corrupted files with defensive fallback.
        Returns: (list_of_valid_records, list_of_warning_messages)
        """
        warnings: List[str] = []
        if not self.json_path.exists():
            # Missing file: initialize clean template
            self._initialize_empty_json()
            return [], ["Initial storage file not found. Created fresh empty harvests.json template."]

        try:
            with open(self.json_path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    # Empty file
                    self._initialize_empty_json()
                    return [], ["Storage file was empty. Reinitialized with clean schema."]
                payload = json.loads(content)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            # Corrupted storage recovery
            backup_name = f"harvests_corrupted_{datetime.now().strftime('%Y%m%d_%H%M%S')}.bak"
            backup_path = self.data_dir / backup_name
            try:
                shutil.copy2(self.json_path, backup_path)
            except Exception:
                pass
            self._initialize_empty_json()
            warnings.append(
                f"CORRUPTION DETECTED in harvests.json: {e}. "
                f"Corrupted file preserved at '{backup_name}'. Reinitialized clean storage."
            )
            return [], warnings

        if not isinstance(payload, dict) or "records" not in payload:
            warnings.append("Schema mismatch: Missing 'records' root list. Re-wrapping content.")
            records_raw = payload if isinstance(payload, list) else []
        else:
            records_raw = payload.get("records", [])

        valid_records: List[HarvestRecord] = []
        for idx, item in enumerate(records_raw):
            try:
                rec = HarvestRecord.from_dict(item)
                valid_records.append(rec)
            except Exception as ex:
                warnings.append(f"Row {idx+1} skipped due to schema mismatch: {ex}")

        return valid_records, warnings

    def save_records(self, records: List[HarvestRecord]) -> bool:
        """Atomically saves records to both JSON and CSV persistence files."""
        payload = {
            "version": self.SCHEMA_VERSION,
            "last_updated": datetime.now().isoformat(),
            "record_count": len(records),
            "records": [r.to_dict() for r in records]
        }

        # Write to JSON atomically
        tmp_json = self.json_path.with_suffix(".tmp")
        try:
            with open(tmp_json, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, ensure_ascii=False)
            if os.path.exists(self.json_path):
                os.remove(self.json_path)
            os.rename(tmp_json, self.json_path)
        except Exception as e:
            if tmp_json.exists():
                tmp_json.unlink(missing_ok=True)
            raise StorageError(f"Failed to persist records to JSON: {e}")

        # Mirror to CSV persistence for multi-format compatibility
        self.export_csv(records, str(self.csv_path))
        return True

    def export_csv(self, records: List[HarvestRecord], filepath: str) -> None:
        """Exports harvest records to structured CSV format."""
        headers = [
            "id", "harvest_date", "crop_name", "category",
            "quantity", "unit", "normalized_kg", "bed_id",
            "quality_grade", "estimated_value", "notes", "created_at"
        ]
        dest_path = Path(filepath)
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_csv = dest_path.with_suffix(".tmp")

        with open(tmp_csv, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            for r in records:
                writer.writerow({
                    "id": r.id,
                    "harvest_date": r.harvest_date,
                    "crop_name": r.crop_name,
                    "category": r.category,
                    "quantity": r.quantity,
                    "unit": r.unit,
                    "normalized_kg": r.normalized_kg,
                    "bed_id": r.bed_id,
                    "quality_grade": r.quality_grade,
                    "estimated_value": r.estimated_value,
                    "notes": r.notes,
                    "created_at": r.created_at,
                })

        if os.path.exists(dest_path):
            os.remove(dest_path)
        os.rename(tmp_csv, dest_path)

    def _initialize_empty_json(self) -> None:
        """Creates a clean JSON storage file with version metadata."""
        empty_payload = {
            "version": self.SCHEMA_VERSION,
            "last_updated": datetime.now().isoformat(),
            "record_count": 0,
            "records": []
        }
        with open(self.json_path, "w", encoding="utf-8") as f:
            json.dump(empty_payload, f, indent=2)
