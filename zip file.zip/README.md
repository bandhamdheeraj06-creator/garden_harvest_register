# 🌿 Garden Harvest Register (Everyday Innovators Project #67)
**Domain:** Food & Agriculture  
**Authors / Students:** Academic Mini Project Submission  

---

## 📖 Project Overview
In community agriculture, institutional gardens, and academic research farms, recording harvested quantities and computing weekly yields manually creates operational friction, calculation errors, and delays in status insights. **Garden Harvest Register** is a robust, beginner-friendly Python application that streamlines harvest data capture, applies defensive validation, computes ISO-calendar weekly totals and growth trends, persists structured records across restarts, and generates executive reports.

---

## 🚀 Key Features

### Core Features (Must-Have)
- **Menu-Driven Interactive Terminal (CLI):** ANSI-styled console interface with guided steps, pagination, and visual ASCII yield charts.
- **Defensive Input Validation:** Real-time sanitization, regex matching, and strict range checks preventing invalid dates, non-numeric quantities, and malformed inputs.
- **Core Business Logic Engine:** Computational algorithms aggregating harvest records into ISO calendar weeks (Monday–Sunday), calculating weekly totals, and tracking chronological growth rates.
- **Local File Persistence:** Dual persistence in structured JSON (`data/harvests.json`) and CSV (`data/harvests.csv`) with automatic recovery from corrupted or missing files.
- **Query & Search Engine:** Multi-criteria keyword, category, date-range, and garden plot filtering with pagination.
- **Executive Summary & KPIs:** Automated aggregation of net yield, discrete count, market valuation, average yield, top crops, and status indicators.

### Stretch Features (Implemented)
- **Multi-Format Summary Export:** Generates GitHub-flavored Markdown executive reports, plain-text cryptographic audit trails, and standardized CSV summaries.
- **Automated Threshold Warnings:** Statistical anomaly detection (yield spikes), spoilage loss alarms, overdue inactive plot warnings, and weekly target shortfalls.
- **Interactive Web Interface (Streamlit):** Web dashboard with interactive bar charts, forms, filters, and one-click data downloads.
- **Desktop Graphical Interface (Tkinter):** Built-in native GUI window with tabbed navigation and modal dialogs.
- **Bulk Legacy Dataset Ingestion:** Ingests legacy spreadsheets with dynamic column alias mapping and row-by-row error validation logs.

---

## 🛠️ Project Structure

```
garden_harvest_register/
├── run_app.py                   # Unified launcher (CLI, GUI, Demo, Export)
├── app_streamlit.py             # Interactive Streamlit Web Interface
├── requirements.txt             # Dependency definitions
├── README.md                    # Project documentation
│
├── garden_harvest/              # Core Application Package
│   ├── __init__.py              # Package metadata
│   ├── models.py                # Dataclasses, Enums, Unit Normalizers
│   ├── validation.py            # Defensive validators & input wrappers
│   ├── persistence.py           # JSON/CSV persistence & corruption recovery
│   ├── business_logic.py        # Weekly totals & trend calculations
│   ├── analytics.py             # Executive KPIs & threshold warnings
│   ├── search.py                # Multi-parameter query & pagination engine
│   ├── exporter.py              # Markdown, audit log, CSV report generator
│   ├── bulk_importer.py         # CSV legacy ingestion & row error logger
│   ├── cli.py                   # Interactive ANSI terminal interface
│   └── gui.py                   # Desktop Tkinter GUI window
│
├── data/                        # Local Storage & Seed Datasets
│   ├── harvests.json            # Active JSON storage file
│   ├── harvests.csv             # Mirrored CSV persistence file
│   ├── sample_harvests.json     # 40 realistic seed harvest records
│   ├── sample_harvests.csv      # CSV format seed records
│   └── legacy_import_sample.csv # Legacy import dataset with edge cases
│
├── exports/                     # Generated reports and audit trails
└── tests/                       # Complete Test Suite (24 unit & integration tests)
    ├── test_models.py
    ├── test_validation.py
    ├── test_persistence.py
    ├── test_business_logic.py
    ├── test_search_and_analytics.py
    ├── test_bulk_importer.py
    └── test_e2e_workflow.py
```

---

## 💻 How to Run the Project

### 1. Launch Interactive Terminal Interface (CLI)
```bash
python main.py
```
*Runs the full menu-driven terminal interface with ANSI styling, defensive input wizard, formatted tables, pagination, and visual ASCII charts.*

### 2. Launch Interactive Web Dashboard (Streamlit)
```bash
python main.py --web
```
*or:*
```bash
streamlit run app_streamlit.py
```
*Opens an interactive browser interface at `http://localhost:8501`.*

### 3. Launch Native Desktop GUI (Tkinter)
```bash
python main.py --gui
```

### 4. Execute Automated Hackathon Demonstration
```bash
python main.py --demo
```

### 5. Run Complete Test Suite
```bash
python main.py --test
```

---

## 📊 Sample Data Included
The project includes **40 realistic harvest records** spanning Weeks 28 through 37 (July–September 2026), covering vegetables, fruits, leafy greens, berries, herbs, legumes, and root crops across various plots with diverse units (kg, g, lbs, oz, pcs, bunches) and quality grades.
