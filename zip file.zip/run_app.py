#!/usr/bin/env python3
"""Garden Harvest Register - Everyday Innovators Project #67
Domain: Food & Agriculture | Hackathon Mentor Guide

Usage:
  python run_app.py              # Launch Interactive Terminal Interface (default)
  python run_app.py --gui        # Launch Lightweight Desktop GUI (Tkinter)
  python run_app.py --demo       # Run automated end-to-end demonstration
  python run_app.py --export     # Auto-export summary reports (Markdown, Audit Log, CSV)
"""

import sys
import argparse
from pathlib import Path

# Add project root to path for direct invocation
project_root = Path(__file__).resolve().parent
sys.path.insert(0, str(project_root))

from garden_harvest.persistence import StorageManager
from garden_harvest.cli import HarvestCLI
from garden_harvest.exporter import ReportExporter
from garden_harvest.analytics import AnalyticsEngine


def run_demo():
    """Executes a fault-tolerant, automated end-to-end user journey demonstration."""
    print("=" * 72)
    print("🌿 GARDEN HARVEST REGISTER - AUTOMATED HACKATHON DEMO RUNNER 🌿")
    print("=" * 72)

    storage = StorageManager()
    records, warnings = storage.load_records()
    print(f"\n[1] Data Persistence Initialization:")
    print(f"    Loaded {len(records)} active harvest records from: {storage.json_path}")
    if warnings:
        for w in warnings:
            print(f"    Notice: {w}")

    print(f"\n[2] Defensive Input Validation Checks:")
    from garden_harvest.validation import validate_crop_name, validate_date, validate_quantity
    test_cases = [
        ("Crop Name valid", validate_crop_name("San Marzano Tomatoes")),
        ("Crop Name empty", validate_crop_name("")),
        ("Harvest Date valid", validate_date("2026-08-15")),
        ("Harvest Date invalid leap year", validate_date("2025-02-29")),
        ("Quantity valid", validate_quantity(12.5)),
        ("Quantity non-numeric", validate_quantity("invalid_weight")),
        ("Quantity negative", validate_quantity(-4.2)),
    ]
    for label, res in test_cases:
        status = "PASSED (Rejected invalid input)" if not res[0] else "PASSED (Accepted valid input)"
        print(f"    • {label:<32} -> {status}")

    print(f"\n[3] Core Business Logic: Weekly Totals & Trends:")
    from garden_harvest.business_logic import BusinessLogicEngine
    weekly = BusinessLogicEngine.calculate_weekly_totals(records)
    print(f"    Calculated {len(weekly)} production weeks:")
    for w in weekly[:5]:
        print(f"    • {w['week_key']} ({w['start_date']} to {w['end_date']}): {w['total_weight_kg']:>6.2f} kg | Trend: {w['trend_symbol']}")

    print(f"\n[4] Executive Summary & Status Indicators:")
    summary = AnalyticsEngine.generate_executive_summary(records)
    print(f"    • Total Net Yield:    {summary['total_weight_kg']} kg across {summary['total_records']} harvests")
    print(f"    • Market Valuation:   ${summary['total_estimated_value']:.2f}")
    print(f"    • Average per Week:   {summary['average_weekly_kg']} kg/week")
    print(f"    • Yield Health:       {summary['status_indicators']['yield_health']}")
    print(f"    • Spoilage Status:    {summary['status_indicators']['spoilage_level']}")

    print(f"\n[5] Multi-Format Report Export Generation:")
    export_dir = storage.data_dir.parent / "exports"
    export_dir.mkdir(parents=True, exist_ok=True)
    md_file = export_dir / "demo_harvest_summary.md"
    txt_file = export_dir / "demo_harvest_audit_log.txt"
    csv_file = export_dir / "demo_harvest_records.csv"

    ReportExporter.export_markdown_report(records, str(md_file))
    ReportExporter.export_audit_log(records, str(txt_file))
    storage.export_csv(records, str(csv_file))
    print(f"    • Markdown Report:   {md_file.name}")
    print(f"    • Plain-Text Audit:  {txt_file.name}")
    print(f"    • Standardized CSV:  {csv_file.name}")

    print(f"\n[6] State Preservation Across Restarts:")
    # Re-initialize fresh storage instance and verify identical state count
    storage_test = StorageManager()
    reloaded, _ = storage_test.load_records()
    assert len(reloaded) == len(records), "Persistence state mismatch on reload!"
    print(f"    • Confirmed: {len(reloaded)} records safely persisted and reloaded with zero data loss.")

    print("\n" + "=" * 72)
    print("✅ DEMO COMPLETED SUCCESSFULLY: ALL CORE REQUIREMENTS VALIDATED.")
    print("=" * 72)


def main():
    parser = argparse.ArgumentParser(
        description="Garden Harvest Register - Everyday Innovators Project #67"
    )
    parser.add_argument("--gui", action="store_true", help="Launch Tkinter desktop GUI")
    parser.add_argument("--cli", action="store_true", help="Launch interactive terminal CLI (default)")
    parser.add_argument("--demo", action="store_true", help="Run automated end-to-end hackathon demonstration")
    parser.add_argument("--export", action="store_true", help="Generate all export reports and exit")

    args = parser.parse_args()

    if args.demo:
        run_demo()
        return

    if args.export:
        storage = StorageManager()
        records, _ = storage.load_records()
        export_dir = storage.data_dir.parent / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)
        md_file = export_dir / "harvest_summary_report.md"
        txt_file = export_dir / "harvest_audit_log.txt"
        csv_file = export_dir / "harvest_records_export.csv"
        ReportExporter.export_markdown_report(records, str(md_file))
        ReportExporter.export_audit_log(records, str(txt_file))
        storage.export_csv(records, str(csv_file))
        print(f"Reports successfully generated in '{export_dir}'.")
        return

    if args.gui:
        try:
            from garden_harvest.gui import launch_gui_app
            launch_gui_app()
        except Exception as e:
            print(f"Failed to launch GUI ({e}). Falling back to Terminal CLI.")
            cli = HarvestCLI()
            cli.run()
    else:
        cli = HarvestCLI()
        cli.run()


if __name__ == "__main__":
    main()
