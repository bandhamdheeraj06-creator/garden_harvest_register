# 🌿 Garden Harvest Register - Executive Summary Report
**Generated:** 2026-11-24 10:28:40 | **Project:** Everyday Innovators #67 | **Domain:** Food & Agriculture

---
## 1. Executive Performance Dashboard

| Metric | Value | Domain Target / Status |
| :--- | :--- | :--- |
| **Total Harvest Log Entries** | 40 records | Baseline Active |
| **Total Harvest Yield (Weight)** | **374.55 kg** | Net Agricultural Production |
| **Total Harvest Count (Discrete)** | 86 pcs/bunches | Herbs & Bunched Greens |
| **Total Estimated Valuation** | **$1232.60** | Market Valuation |
| **Average Yield per Harvest** | 9.36 kg | Operational Efficiency |
| **Average Weekly Production** | 37.45 kg/week | Target: 25.0 kg/week |
| **Active Recording Window** | 2026-07-07 to 2026-09-12 (68 days) | Active Span |

### Operational Status Indicators
- **Yield Health**: 🟢 Target Exceeded (37.45 kg/wk vs 25.0 kg goal)
- **Spoilage & Loss**: 🟢 Excellent (<4% damaged: 1.6%)
- **Production Velocity**: 📉 Slowing (-32.8% drop)

---
## 2. Weekly Production & Chronological Trends

| Week Key | Date Window | Total Yield (kg) | Units (pcs) | Est. Value ($) | Trend vs Prior Week | Top Crop |
| :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| `2026-W28` | 2026-07-06 to 2026-07-12 | **8.20 kg** | 12 | $64.55 | 🆕 New | Lacinato Kale |
| `2026-W29` | 2026-07-13 to 2026-07-19 | **26.60 kg** | 18 | $108.30 | 📈 +224.4% | Butterhead Lettuce |
| `2026-W30` | 2026-07-20 to 2026-07-26 | **34.25 kg** | 0 | $92.20 | 📈 +28.8% | Roma Tomatoes |
| `2026-W31` | 2026-07-27 to 2026-08-02 | **38.00 kg** | 0 | $131.50 | 📈 +10.9% | Cherokee Purple Tomatoes |
| `2026-W32` | 2026-08-03 to 2026-08-09 | **42.70 kg** | 0 | $124.70 | 📈 +12.4% | Roma Tomatoes |
| `2026-W33` | 2026-08-10 to 2026-08-16 | **26.70 kg** | 10 | $122.50 | 📉 -37.5% | Heirloom Beefsteak Tomatoes |
| `2026-W34` | 2026-08-17 to 2026-08-23 | **43.40 kg** | 32 | $153.00 | 📈 +62.5% | Sweet Corn (Golden Bantam) |
| `2026-W35` | 2026-08-24 to 2026-08-30 | **48.55 kg** | 0 | $91.80 | 📈 +11.9% | Watermelon (Sugar Baby) |
| `2026-W36` | 2026-08-31 to 2026-09-06 | **63.50 kg** | 14 | $162.25 | 📈 +30.8% | Butternut Squash |
| `2026-W37` | 2026-09-07 to 2026-09-13 | **42.65 kg** | 0 | $181.80 | 📉 -32.8% | Gala Apples |

---
## 3. Crop & Category Aggregations

### Crop Category Distribution
| Category | Total Yield (kg) | Units (pcs) | Entries | Est. Value ($) | Crops Cultivated |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Fruit** | 200.30 kg | 0 | 10 | $518.40 | 9 varieties |
| **Vegetable** | 101.50 kg | 32 | 12 | $261.00 | 12 varieties |
| **Root & Tuber** | 48.70 kg | 0 | 4 | $99.15 | 4 varieties |
| **Legume** | 11.60 kg | 0 | 2 | $39.00 | 2 varieties |
| **Berry** | 10.90 kg | 0 | 3 | $84.80 | 3 varieties |
| **Herb** | 1.55 kg | 0 | 5 | $131.25 | 5 varieties |
| **Leafy Green** | 0.00 kg | 54 | 4 | $99.00 | 4 varieties |

### Top 5 Performing Crops by Weight
| Rank | Crop Variety | Total Yield (kg) | % of Total Weight |
| :---: | :--- | :---: | :---: |
| 1 | **Roma Tomatoes** | 38.9 kg | 10.4% |
| 2 | **Gala Apples** | 38.0 kg | 10.1% |
| 3 | **Watermelon (Sugar Baby)** | 34.5 kg | 9.2% |
| 4 | **Sweet Corn (Golden Bantam)** | 32.0 kg | 8.5% |
| 5 | **Butternut Squash** | 28.0 kg | 7.5% |

---
## 4. Garden Bed & Plot Efficiency

| Bed / Plot Identifier | Total Weight (kg) | Harvest Events | Spoilage Rate | Est. Value ($) |
| :--- | :---: | :---: | :---: | :---: |
| `Bed-1` | 129.20 kg | 8 | 0.0% | $407.45 |
| `Orchard-Plot` | 86.20 kg | 6 | 3.2% | $212.55 |
| `Bed-2` | 56.10 kg | 5 | 0.0% | $121.35 |
| `Bed-3` | 45.80 kg | 5 | 7.0% | $79.70 |
| `Greenhouse-North` | 28.20 kg | 6 | 0.0% | $108.30 |
| `Bed-4` | 28.00 kg | 2 | 0.0% | $88.00 |
| `Raised-Bed-B` | 1.05 kg | 4 | 0.0% | $116.25 |
| `Raised-Bed-A` | 0.00 kg | 4 | 0.0% | $99.00 |

---
## 5. Threshold Warning Indicators & Audit Alerts

- **[CRITICAL] SPOILAGE_LOSS**: Significant harvest spoilage loss in Bed-3: 3.2 kg of Zucchini (Overripe / Damaged) marked as Damaged on 2026-08-12. Notes: 'Overgrown fibrous fruit damaged by hail.'
- **[CRITICAL] SPOILAGE_LOSS**: Significant harvest spoilage loss in Orchard-Plot: 2.8 kg of Damaged Late Plums marked as Damaged on 2026-09-12. Notes: 'Wasp and bird damage after wind.'

---
## 6. Harvest Quality Inspection Distribution

- **Grade A (Premium)**: 32 entries (80.0%)
- **Grade B (Standard)**: 6 entries (15.0%)
- **Damaged / Spoiled**: 2 entries (5.0%)
